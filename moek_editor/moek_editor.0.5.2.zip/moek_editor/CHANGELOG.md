# Changelog (dziennik zmian):

## [0.5.2] - 2021-10-11 (hotfix)
### Poprawiono:
- Naprawiono błąd zapisu edycji geometrii wyrobisk przy otwartym własnym pliku projektowym. Aby błąd przestał występować, należy warstwy własne projektu (bez warstw systemowych wtyczki) zapisać jako definicję warstw. Następnie uruchomić wtyczkę na pustym projekcie, tak aby utworzyły się nowe warstwy systemowe. Na koniec należy wczytać własne warstwy z uwcześnie zapisanej definicji warstw i tak przygotowany projekt zapisać pod nową nazwą.

## [0.5.1] - 2021-10-11 (hotfix)
### Poprawiono
- Naprawiono błąd zapisu do bazy danych wartości tekstowych w atrybutach dotyczących okresu eksploatacji.

## [0.5.0] - 2021-10-07
### Dodano
- Wprowadzono możliwość nadawania flagom roboczych (terenowych) numerów identyfikacyjnych.
- Wprowadzono pełną listę funkcji i narzędzi obsługujących wyrobiska, m.in.: zmiana statusu wyrobiska, automatyczne ustalenie przynależności administracyjnej (miejscowość, gmina), automatyczna numeracja (zgodna ze standardami map seryjnych) wyrobisk potwierdzonych, możliwość powiązania wyrobisk ze złożami i punktami WN_PNE, uzupełnianie wszystkich atrybutów wyrobisk (wymaganych w bazie danych i w kartach wyrobisk) za pomocą formularzy, które posiadają reguły uniemożliwiające powstawanie tzw. błędów wykluczających.

### Zmieniono
- Przeniesiono przyciski obsługujące sekwencje podkładów z panelu "Siatka widoków" do samodzielnego panelu umiejscowionego w lewym dolnym rogu okna mapowego. Pozwala to na korzystanie z sekwencji podkładów również po wyłączeniu siatki widoków.
- Uproszczono obsługę widget'u do wpisywania uwag/notatek.
- Rozbudowano panel "Wyrobiska" o listę wybieralną dostępnych wyrobisk (która może służyć do przełączania się między obiektami) oraz narzędzia mapowe i formularze do uzupełniania atrybutów wyrobisk.
- W celu zwiększenia przejrzystości interfejsu użytkownika, zmodyfikowano i ujednolicono jego kolorystykę.

### Poprawiono
- Zmodyfikowano zdeaktualizowany adres WMS podkładu BDOO.
- Wyeliminowano zacinanie się funkcji odtwarzania sekwencji podkładów podczas przepatrywania siatki widoków.

## [0.4.0] - 2021-06-30
### Dodano
- Wprowadzono nowe obiekty - miejsca parkowania i marszruty. Ułatwiają one planowanie tras kontroli terenowych oraz umożliwiają ich sprawną realizację (przy wykorzystaniu aplikacji mobilnej na tablet/smartfon).
- Do głównego okna wtyczki dodano panel "Komunikacja" do włączania/wyłączania oraz filtrowania parkingów i marszrut.
- Dodano moduł eksportu danych z serwera na dysk lokalny. Możliwy jest zapis danych w postaci plików typu: geopackage, kml i shapefile.

### Poprawiono
- Wiele drobnych błędów.

## [0.3.0] - 2021-04-20
### Dodano
- Uruchamianie wtyczki z otwartym "własnym" plikiem projektowym (możliwość korzystania z dodatkowych warstw danych).
- Do głównego okna wtyczki dodano panele "Flagi" i "Wyrobiska" z przyciskami filtrującymi wyświetlane obiekty.
- Aby zminimalizować ilość zajętego miejsca okna wtyczki w doku, wprowadzono możliwość "zwijania" niektórych paneli.
- Do panelu powiatów dodano przycisk włączenia/wyłączenia trybu maskowania obszarów spoza aktywnych powiatów.
- Wszystkie ustawienia stanu i widoczności paneli oraz warstw obiektów są zapamiętywane na poziomie zespołu (każdy zespół może mieć swój zestaw ustawień) i wczytywane przy uruchamianiu wtyczki (lub przełączaniu między zespołami).
- Wprowadzono podział wyrobisk na: "wyrobiska przed kontrolą terenową", "wyrobiska potwierdzone" i "wyrobiska odrzucone".
- Po kliknięciu na mapie w symbol punktu WN_PNE, pojawia się panel WN_Kopaliny_PNE z informacjami dotyczącymi danego punktu.
- Punkty WN_PNE zostały przypisane do powiatów i na mapie wyświetlane są wyłącznie te, które należą do aktywnego powiatu/powiatów.
- Punkty WN_PNE leżące w zasięgu 1 km bufora od granic powiatów, są przypisane do wszystkich przyległych powiatów - wykonawca może w panelu WN_Kopaliny_PNE wyłączyć powiaty, do których punkt nie należy.
- Wprowadzono możliwość przełączania się pomiędzy punktami WN_PNE, wpisując znany numer 'id_arkusz' (należy wpisać pełną nazwę, np. '0778_008', a nie '778_008').

### Zmieniono
- Wygląd i sposób wyświetlania etykiet powiatów.
- Zmodyfikowano adresy WMS, aby wyświetlały polskie nazwy miejscowości.

### Poprawiono
- Program nie zawiesza się przy zamykaniu, gdy wtyczka jest włączona (nie trzeba już wyłączać wtyczki przed zamknięciem QGIS).
- Wiele drobnych błędów.
