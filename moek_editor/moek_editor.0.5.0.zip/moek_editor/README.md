# MOEK Editor
---
Wtyczka QGIS przeznaczona dla wykonawców Monitoringu Odkrywkowej Eksploatacji Kopalin prowadzonego w Państwowym Instytucie Geologicznym – Państwowym Instytucie Badawczym (PIG-PIB).