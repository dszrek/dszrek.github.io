class CompassRoseItem(QgsMapCanvasItem):
    def __init__(self, canvas):
        QgsMapCanvasItem.__init__(self, canvas)
        self.center = QgsPointXY(0, 0)
        self.size = 100

    def setCenter(self, center):
        self.center = center

    def center(self):
        return self.center

    def setSize(self, size):
        self.size = size

    def size(self):
        return self.size

    def boundingRect(self):
        return QRectF(
                    self.center.x() - self.size/2,
                    self.center.y() - self.size/2,
                    self.center.x() + self.size/2,
                    self.center.y() + self.size/2
                    )

    def paint(self, painter, option, widget):
        fontSize = int(18 * self.size/100)
        painter.setFont(QFont("Times",pointSize=fontSize,weight=75))
        metrics = painter.fontMetrics()
        labelSize = metrics.height()
        margin = 5
        # x = self.center.x()
        # y = self.center.y()
        size = self.size - labelSize - margin
        path = QPainterPath()
        path.moveTo(x, y - size * 0.23)
        path.lineTo(x - size * 0.45, y - size * 0.45)
        path.lineTo(x - size * 0.23, y)
        path.lineTo(x - size * 0.45, y + size * 0.45)
        path.lineTo(x, y + size * 0.23)
        path.lineTo(x + size * 0.45, y + size * 0.45)
        path.lineTo(x + size * 0.23, y)
        path.lineTo(x + size * 0.45, y - size * 0.45)
        path.closeSubpath()
        painter.fillPath(path, QColor("light gray"))
        path = QPainterPath()
        path.moveTo(x, y - size)
        path.lineTo(x - size * 0.18, y - size * 0.18)
        path.lineTo(x - size, y)
        path.lineTo(x - size * 0.18, y + size * 0.18)
        path.lineTo(x, y + size)
        path.lineTo(x + size * 0.18, y + size * 0.18)
        path.lineTo(x + size, y)
        path.lineTo(x + size * 0.18, y - size * 0.18)
        path.closeSubpath()
        painter.fillPath(path, QColor("black"))
        labelX = x - metrics.width("N")/2
        labelY = y - self.size + labelSize - metrics.descent()
        painter.drawText(QPoint(labelX, labelY), "N")
        labelX = x - metrics.width("S")/2
        labelY = y + self.size - labelSize + metrics.ascent()
        painter.drawText(QPoint(labelX, labelY), "S")
        labelX = x - self.size + labelSize/2 - metrics.width("E")/2
        labelY = y - metrics.height()/2 + metrics.ascent()
        painter.drawText(QPoint(labelX, labelY), "E")
        labelX = x + self.size - labelSize/2 - metrics.width("W")/2
        labelY = y - metrics.height()/2 + metrics.ascent()
        painter.drawText(QPoint(labelX, labelY), "W")

class MultiMapTool(QgsMapToolIdentify):
    """Domyślny maptool łączący funkcje nawigacji po mapie i selekcji obiektów."""
    identified = pyqtSignal(object, object, str)
    cursor_changed = pyqtSignal(str)

    def __init__(self, canvas, layer):
        QgsMapToolIdentify.__init__(self, canvas)
        self.canvas = canvas
        self.layer = layer
        self.dragging = False
        self.cursor_changed.connect(self.cursor_change)
        # self.mt_cur = QCursor()
        # self.setCursor(self.mt_cur)
        self.cursor = "open_hand"
        # self.cur_pos = None
        # self.cur_stop = False
        # self.tick = False
        # self.timer = QTimer()
        # self.timer.timeout.connect(self.tack)
        # self.timer.start(2000)
        # self._print = run_in_main_thread(print)



def findFeatureAt(self, pos):
        # th = self.transformCoordinates(pos)
        # mapPt,layerPt = th.get()
        # print(f"map_x: {mapPt.x()}, lyr_x: {layerPt.x()}, map_y: {mapPt.y()}, lyr_y: {layerPt.y()}")
        # mapPt,layerPt = self.transformCoordinates(pos)
        # tolerance = self.calcTolerance(pos)
        tolerance = 100.0
        searchRect = QgsRectangle(pos.x() - tolerance,
                                  pos.y() - tolerance,
                                  pos.x() + tolerance,
                                  pos.y() + tolerance)
        request = QgsFeatureRequest()
        request.setFilterRect(searchRect)
        # request.setSubsetOfAttributes(['id'], self.layer.fields())
        request.setFlags(QgsFeatureRequest.ExactIntersect)
        feats = []
        # for lyr in self.layer:
        #     # print(lyr)
        #     for feat in lyr.getFeatures(request):
        #         print(feat)
        #         feats.append(feat)
        # if len(feats) == 1:
        #     print(feat[0])
        #     return feat[0]
        # else:
        #     return None
        for feature in self.layer[0].getFeatures(request):
            return feature
        return None


class EditTool(QgsMapTool):
    cursor_changed = pyqtSignal(str)

    def __init__(self, canvas, layer):
        QgsMapTool.__init__(self, canvas)
        self.setCursor(Qt.CrossCursor)
        self.layer = layer
        self.dragging = False
        self.feature = None
        self.sel = False
        self.cursor_changed.connect(self.cursor_change)
        self.cursor = "open_hand"
        # self.feats = []
        # self.index = QgsSpatialIndex()
        # t1 = tm.perf_counter()
        # self.indexing()
        # t2 = tm.perf_counter()
        # print(f"indexing: {round(t2-t1, 2)}")
        # self.timer = QTimer()
        # self.timer.timeout.connect(self.tack)
        # self.timer.start(100)

    def indexing(self):
        # for lyr in self.layer:
        #     dp = lyr.dataProvider()
        #     feat = QgsFeature()
        #     all_attrs = dp.attributeIndexes()
        #     dp.select(all_attrs)
        #     while dp.nextFeature(feat):
        #         self.index.insertFeature(feat)

        # request = QgsFeatureRequest()
        for lyr in self.layer:
            for feat in lyr.getFeatures():
                self.feats.append(feat)
                # for attr in feat.attributes():
                #     self.feats.append(attr.toString())
        #         return feat
        # # for lyr in self.layer:
        # #     # Select all features along with their attributes
        # #     # allAttrs = lyr.allAttributes()
        # #     # lyr.select(allAttrs)
        # #     # allfeatures = #{feature.id(): feature for (feature) in lyr}
        # #     self.feats.append(lyr.getFeatures())
        # map(self.index.addFeatures, self.feats)
        # print(self.index)
        # for feat in self.feats:
        self.index.addFeatures(self.feats)


    def cursor_change(self, cur_name):
        """Zmiana cursora maptool'a."""
        cursors = [
                    ["arrow", Qt.ArrowCursor],
                    ["open_hand", Qt.OpenHandCursor],
                    ["closed_hand", Qt.ClosedHandCursor]
                ]
        for cursor in cursors:
            if cursor[0] == cur_name:
                self.setCursor(cursor[1])
                break

    def __setattr__(self, attr, val):
        """Przechwycenie zmiany atrybutu."""
        super().__setattr__(attr, val)
        if attr == "cursor":
            self.cursor_changed.emit(val)

    def canvasMoveEvent(self, event):
        th = self.findFeatureAt(event.pos())
        feature = th.get()
        if feature == None:
            if self.sel:
                self.cursor = "open_hand"
                self.sel = False
        else:
            if not self.sel:
                self.cursor = "arrow"
                self.sel = True

    @threading_func
    def findFeatureAt(self, pos):
        pos = self.toLayerCoordinates(self.layer[0], pos)
        scale = iface.mapCanvas().scale()
        tolerance = scale / 250
        search_rect = QgsRectangle(pos.x() - tolerance,
                                  pos.y() - tolerance,
                                  pos.x() + tolerance,
                                  pos.y() + tolerance)
        request = QgsFeatureRequest()
        request.setFilterRect(search_rect)
        # near = self.index.nearestNeighbor(pos, 1)
        # request.setFilterFids(near)

        # request.setSimplifyMethod()
        # request.setNoAttributes()
        # request.setSubsetOfAttributes(['id'], self.layer.fields())
        request.setFlags(QgsFeatureRequest.ExactIntersect)
        # feats = []
        t1 = tm.perf_counter()
        for lyr in self.layer:
            for feat in lyr.getFeatures(request):
                return feat
        t2 = tm.perf_counter()
        print(f"feat: {round(t2-t1, 2)}")
        # print(f"pos: {round(t2-t1, 2)}, scale: {round(t3-t2, 2)}, tolerance: {round(t4-t3, 2)}, request: {round(t5-t4, 2)}, feat: {round(t6-t5, 2)}, all: {round(t6-t1, 2)}")
        return None
        # if len(feats) > 0:
        #     return feats[0]
        # else:
        #     return None
        # for feature in self.layer.getFeatures(request):
        #     return feature
        # return None



class EditPolyMapTool(QgsMapTool):
    """Maptool do edytowania poligonalnej geometrii wyrobiska."""
    cursor_changed = pyqtSignal(str)
    ending = pyqtSignal(QgsVectorLayer, QgsGeometry)

    def __init__(self, canvas, layer, geom, button):
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self._button = button
        if not self._button.isChecked():
            self._button.setChecked(True)
        self.layer = layer
        self.geom = geom
        self.dragging = False
        # self.begin = True

        self.feat_band = MoekRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self.feat_band.setColor(QColor(0, 0, 255, 255))
        self.feat_band.setFillColor(QColor(0, 0, 255, 80))
        self.feat_band.setWidth(2)
        self.feat_band.addGeometry(self.geom)

        self.snap_marker = QgsRubberBand(self.canvas, QgsWkbTypes.PointGeometry)
        self.snap_marker.setIcon(QgsRubberBand.ICON_CIRCLE)
        self.snap_marker.setColor(QColor(0, 0, 255, 255))
        self.snap_marker.setFillColor(QColor(0, 0, 255, 64))
        self.snap_marker.setIconSize(12)
        # self.snap_marker.setVisible(False)

        for part in self.geom.parts():
            for p in part.vertices():
                self.snap_marker.addPoint(QgsPointXY(p.x(), p.y()))

        self.cursor_changed.connect(self.cursor_change)
        self.cursor = "open_hand"

    def button(self):
        return self._button

    def __setattr__(self, attr, val):
        """Przechwycenie zmiany atrybutu."""
        super().__setattr__(attr, val)
        if attr == "cursor":
            self.cursor_changed.emit(val)

    def cursor_change(self, cur_name):
        """Zmiana cursora maptool'a."""
        cursors = [
                    ["arrow", Qt.ArrowCursor],
                    ["open_hand", Qt.OpenHandCursor],
                    ["closed_hand", Qt.ClosedHandCursor]
                ]
        for cursor in cursors:
            if cursor[0] == cur_name:
                self.setCursor(cursor[1])
                break

    # def canvasMoveEvent(self, event):
    #     if event.buttons() == Qt.LeftButton:
    #         dlg.flag_menu.hide()
    #         self.dragging = True
    #         self.cursor = "closed_hand"
    #         self.canvas.panAction(event)
    #     elif event.buttons() == Qt.NoButton and not self.dragging:
    #         # th = self.findFeatureAt(event.pos())
    #         # feat = th.get()
    #         # if feat == None:
    #         #     if self.sel:
    #         #         self.cursor = "open_hand"
    #         #         self.sel = False
    #         # else:
    #         #     if not self.sel:
    #         #         self.cursor = "arrow"
    #         #         self.sel = True

    @threading_func
    def findFeatureAt(self, pos):
        pos = self.toLayerCoordinates(self.feat_band, pos)
        scale = self.canvas.scale()
        tolerance = scale / 250
        search_rect = QgsRectangle(pos.x() - tolerance,
                                  pos.y() - tolerance,
                                  pos.x() + tolerance,
                                  pos.y() + tolerance)
        request = QgsFeatureRequest()
        request.setFilterRect(search_rect)
        request.setFlags(QgsFeatureRequest.ExactIntersect)
        for lyr in self.layer:
            for feat in lyr.getFeatures(request):
                return feat
        return None

    # def snap_to_editable_layer(self, event):
    #     """ Temporarily override snapping config and snap to vertices and edges
    #      of any editable vector layer, to allow selection of node for editing
    #      (if snapped to edge, it would offer creation of a new vertex there).
    #     """

    #     map_point = self.toMapCoordinates(event.pos())
    #     tol = QgsTolerance.vertexSearchRadius(self.canvas.mapSettings())
    #     snap_type = QgsPointLocator.Type(QgsPointLocator.Vertex|QgsPointLocator.Edge)

    #     snap_layers = []
    #     for layer in self.canvas().layers():
    #         if not isinstance(layer, QgsVectorLayer) or not layer.isEditable():
    #             continue
    #         snap_layers.append(QgsSnappingUtils.LayerConfig(
    #             layer, snap_type, tol, QgsTolerance.ProjectUnits))

    #     snap_util = self.canvas().snappingUtils()
    #     old_layers = snap_util.layers()
    #     old_mode = snap_util.snapToMapMode()
    #     old_intersections = snap_util.snapOnIntersections()
    #     snap_util.setLayers(snap_layers)
    #     snap_util.setSnapToMapMode(QgsSnappingUtils.SnapAdvanced)
    #     snap_util.setSnapOnIntersections(False)  # only snap to layers
    #     m = snap_util.snapToMap(map_point)

    #     # try to stay snapped to previously used feature
    #     # so the highlight does not jump around at nodes where features are joined
    #     if self.last_snap is not None:
    #         filter_last = OneFeatureFilter(self.last_snap.layer(), self.last_snap.featureId())
    #         m_last = snap_util.snapToMap(map_point, filter_last)
    #         if m_last.isValid() and m_last.distance() <= m.distance():
    #             m = m_last

    #     snap_util.setLayers(old_layers)
    #     snap_util.setSnapToMapMode(old_mode)
    #     snap_util.setSnapOnIntersections(old_intersections)

    #     self.last_snap = m

    #     return m


    def canvasPressEvent(self, event):
        if event.button() == Qt.RightButton:
            self.reset()

    def reset(self):
        self.clearMapCanvas()
        self.ending.emit(self.layer, self.geom)

    def clearMapCanvas(self):
        self.feat_band.reset(QgsWkbTypes.PolygonGeometry)
        self.snap_marker.reset(QgsWkbTypes.PointGeometry)


class MoekRubberBand(QgsRubberBand):
    def __init__(self, canvas, geom_type):
        QgsRubberBand.__init__(self, canvas, geom_type)
        print("guma on")

    def hoverMoveEvent(self, event):
        QgsRubberBand.hoverMoveEvent(event)
        print("move")


class EditPolyMapTool(QgsMapTool):
    """Maptool do edytowania poligonalnej geometrii wyrobiska."""
    cursor_changed = pyqtSignal(str)
    ending = pyqtSignal(QgsVectorLayer, QgsGeometry)

    def __init__(self, canvas, layer, geom, button):
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self._button = button
        if not self._button.isChecked():
            self._button.setChecked(True)
        self.layer = layer
        self.geom = geom
        self.dragging = False
        # self.begin = True

        self.feat_band = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self.feat_band.setColor(QColor(0, 0, 255, 255))
        self.feat_band.setFillColor(QColor(0, 0, 255, 80))
        self.feat_band.setWidth(2)
        self.feat_band.addGeometry(self.geom)

        self.snap_marker = QgsRubberBand(self.canvas, QgsWkbTypes.PointGeometry)
        self.snap_marker.setIcon(QgsRubberBand.ICON_CIRCLE)
        self.snap_marker.setColor(QColor(0, 0, 255, 255))
        self.snap_marker.setFillColor(QColor(0, 0, 255, 64))
        self.snap_marker.setIconSize(12)

        for part in self.geom.parts():
            for p in part.vertices():
                self.snap_marker.addPoint(QgsPointXY(p.x(), p.y()))

        self.cursor_changed.connect(self.cursor_change)
        self.cursor = "open_hand"

    def button(self):
        return self._button

    def __setattr__(self, attr, val):
        """Przechwycenie zmiany atrybutu."""
        super().__setattr__(attr, val)
        if attr == "cursor":
            self.cursor_changed.emit(val)

    def cursor_change(self, cur_name):
        """Zmiana cursora maptool'a."""
        cursors = [
                    ["arrow", Qt.ArrowCursor],
                    ["open_hand", Qt.OpenHandCursor],
                    ["closed_hand", Qt.ClosedHandCursor]
                ]
        for cursor in cursors:
            if cursor[0] == cur_name:
                self.setCursor(cursor[1])
                break


, QgsVertexMarker

, QgsExpression, QgsTolerance, QgsPointLocator, edit

        # self.sel_id = None
        # self.layers = [
        #     {"name" : "flagi_z_teren", "id_col" : 0},
        #     {"name" : "flagi_bez_teren", "id_col" : 0}
        # ]


class MoekMenuFlag(QFrame):
    """Menu przyborne dla flag."""
    def __init__(self, *args):
        super().__init__(*args)
        self.setParent(iface.mapCanvas())
        self.setCursor(Qt.ArrowCursor)
        self.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.setFixedSize(112, 48)
        self.setObjectName("main")
        self.pointer = MoekPointer()
        self.pointer.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.pointer.setFixedSize(12, 6)
        self.pointer.setObjectName("pointer")
        self.box = QFrame()
        self.box.setObjectName("box")
        self.box.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setStyleSheet("""
                    QFrame#main{background-color: transparent; border: none}
                    QFrame#box{background-color: rgba(0,0,0,0.6); border: none}
                    """)
        vlay = QVBoxLayout()
        vlay.setContentsMargins(0, 0, 0, 0)
        vlay.setSpacing(0)
        vlay.addWidget(self.pointer)
        vlay.addWidget(self.box)
        vlay.setAlignment(self.pointer, Qt.AlignCenter)
        self.setLayout(vlay)
        self.flag_move = MoekButton(name="move", size=34, checkable=True)
        self.flag_chg = MoekButton(name="flag_chg_nfchk", size=34)
        self.flag_del = MoekButton(name="trash", size=34)
        hlay = QHBoxLayout()
        hlay.setContentsMargins(4, 4, 4, 4)
        hlay.setSpacing(1)
        hlay.addWidget(self.flag_move)
        hlay.addWidget(self.flag_chg)
        hlay.addWidget(self.flag_del)
        self.box.setLayout(hlay)
        self.fchk = False
        self.flag_move.clicked.connect(self.init_move)
        self.flag_chg.clicked.connect(self.flag_fchk_change)
        self.flag_del.clicked.connect(self.flag_delete)

    def __setattr__(self, attr, val):
        """Przechwycenie zmiany atrybutu."""
        super().__setattr__(attr, val)
        if attr == "fchk":
            self.flag_chg.set_icon(name="flag_chg_nfchk", size=34) if val else self.flag_chg.set_icon(name="flag_chg_fchk", size=34)

    def init_move(self):
        """Zmiana lokalizacji flagi."""
        dlg.obj.flag_hide(True)
        dlg.obj.menu_hide()
        dlg.mt.init("flag_move")

    def flag_fchk_change(self):
        """Zmiana rodzaju flagi."""
        table = f"team_{str(dlg.team_i)}.flagi"
        bns = f" WHERE id = {dlg.obj.flag}"
        db_attr_change(tbl=table, attr="b_fieldcheck", val=not self.fchk, sql_bns=bns, user=False)
        dlg.obj.flag = None
        dlg.obj.menu_hide()

    def flag_delete(self):
        """Usunięcie flagi z bazy danych."""
        db = PgConn()
        sql = "DELETE FROM team_" + str(dlg.team_i) + ".flagi WHERE id = " + str(dlg.obj.flag) + ";"
        if db:
            res = db.query_upd(sql)
            if res:
                dlg.obj.flag = None
        dlg.obj.menu_hide()


    def menu_show(self):
        """Pokazanie menu podręcznego flag."""
        if self.flag_menu:
            return
        extent =iface.mapCanvas().extent()
        geom = self.flag_data[2]
        x_map = round(extent.xMaximum()) - round(extent.xMinimum())
        y_map = round(extent.yMaximum()) - round(extent.yMinimum())
        xp = round(geom.x()) - round(extent.xMinimum())
        yp = round(extent.yMaximum()) - round(geom.y())
        x_scr = round(xp * iface.mapCanvas().width() / x_map)
        y_scr = round(yp * iface.mapCanvas().height() / y_map)
        dlg.flag_menu.move(x_scr - 56, y_scr + 25)
        dlg.flag_menu.show()
        self.flag_menu = True


    uri = "crs=EPSG:3857&format&type=xyz&url=https://mt1.google.com/vt/lyrs%3Ds%26x%3D%7Bx%7D%26y%3D%7By%7D%26z%3D%7Bz%7D&zmax=18&zmin=0"
    lyr = QgsRasterLayer(uri, "Google Satellite", "wms")
    if not lyr.isValid():
        print("Layer failed to load!")
        return
    proj.addMapLayer(lyr, False)
    parent_grp = root.findGroup("sat")
    node = parent_grp.addLayer(lyr)
    node.setItemVisibilityChecked(True)
    lyr.loadNamedStyle(f"{STYLE_PATH}google satellite.qml")


    # ================= wyr_point
    uri = f'{PARAMS} table="team_{dlg.team_i}"."wyrobiska" (centroid) sql=wyr_id = 0'
    lyr = QgsVectorLayer(uri, "wyr_point", "postgres")
    proj.addMapLayer(lyr, False)
    parent_grp = root.findGroup("wyrobiska")
    node = parent_grp.addLayer(lyr)
    node.setItemVisibilityChecked(True)
    lyr.loadNamedStyle(f"{STYLE_PATH}wyr_point.qml")
    te = tm.perf_counter()
    print(f"wyr_point: {round(te - ts, 2)}")

    # ================= wyr_poly
    uri = f'{PARAMS} table="team_{dlg.team_i}"."wyr_geom" (geom) sql=wyr_id = 0'
    lyr = QgsVectorLayer(uri, "wyr_poly", "postgres")
    proj.addMapLayer(lyr, False)
    parent_grp = root.findGroup("wyrobiska")
    node = parent_grp.addLayer(lyr)
    node.setItemVisibilityChecked(True)
    lyr.loadNamedStyle(f"{STYLE_PATH}wyr_poly.qml")

    # ================= flagi_z_teren
    uri = f'{PARAMS} table="team_{dlg.team_i}"."flagi" (geom) sql=b_fieldcheck = True'
    lyr = QgsVectorLayer(uri, "flagi_z_teren", "postgres")
    proj.addMapLayer(lyr, False)
    parent_grp = root.findGroup("flagi")
    node = parent_grp.addLayer(lyr)
    node.setItemVisibilityChecked(True)
    lyr.loadNamedStyle(f"{STYLE_PATH}flagi_z_teren.qml")

    # ================= flagi_bez_teren
    uri = f'{PARAMS} table="team_{dlg.team_i}"."flagi" (geom) sql=b_fieldcheck = False'
    lyr = QgsVectorLayer(uri, "flagi_bez_teren", "postgres")
    proj.addMapLayer(lyr, False)
    parent_grp = root.findGroup("flagi")
    node = parent_grp.addLayer(lyr)
    node.setItemVisibilityChecked(True)
    lyr.loadNamedStyle(f"{STYLE_PATH}flagi_bez_teren.qml")

    # ================= wn_kopaliny_pne
    uri = f'{PARAMS} table="external"."wn_kopaliny_pne" (geom) sql='
    lyr = QgsVectorLayer(uri, "wn_kopaliny_pne", "postgres")
    proj.addMapLayer(lyr, False)
    parent_grp = root
    parent_grp.insertChildNode(2, QgsLayerTreeLayer(lyr))
    parent_grp.findLayer(lyr).setItemVisibilityChecked(True)
    lyr.loadNamedStyle(f"{STYLE_PATH}wn_kopaliny_pne.qml")

    # ================= powiaty
    uri = f'{PARAMS} table="team_{dlg.team_i}"."powiaty" (geom) sql='
    lyr = QgsVectorLayer(uri, "powiaty", "postgres")
    proj.addMapLayer(lyr, False)
    parent_grp = root
    parent_grp.insertChildNode(3, QgsLayerTreeLayer(lyr))
    parent_grp.findLayer(lyr).setItemVisibilityChecked(True)
    lyr.loadNamedStyle(f"{STYLE_PATH}powiaty.qml")

    # ================= arkusze
    uri = f'{PARAMS} table="team_{dlg.team_i}"."arkusze" (geom) sql='
    lyr = QgsVectorLayer(uri, "arkusze", "postgres")
    proj.addMapLayer(lyr, False)
    parent_grp = root
    parent_grp.insertChildNode(4, QgsLayerTreeLayer(lyr))
    parent_grp.findLayer(lyr).setItemVisibilityChecked(True)
    lyr.loadNamedStyle(f"{STYLE_PATH}arkusze.qml")

    # ================= vn_sel
    uri = f'{PARAMS} table="team_{dlg.team_i}"."team_viewnet" (geom) sql=user_id = {dlg.user_id} AND b_sel IS TRUE'
    lyr = QgsVectorLayer(uri, "vn_sel", "postgres")
    proj.addMapLayer(lyr, False)
    parent_grp = root.findGroup("vn")
    node = parent_grp.addLayer(lyr)
    node.setItemVisibilityChecked(True)
    lyr.loadNamedStyle(f"{STYLE_PATH}vn_sel.qml")

    # ================= vn_user
    uri = f'{PARAMS} table="team_{dlg.team_i}"."team_viewnet" (geom) sql=user_id = {dlg.user_id}'
    lyr = QgsVectorLayer(uri, "vn_user", "postgres")
    proj.addMapLayer(lyr, False)
    parent_grp = root.findGroup("vn")
    node = parent_grp.addLayer(lyr)
    node.setItemVisibilityChecked(True)
    lyr.loadNamedStyle(f"{STYLE_PATH}vn_user.qml")

    # ================= vn_other
    uri = f'{PARAMS} table="team_{dlg.team_i}"."team_viewnet" (geom) sql=user_id <> {dlg.user_id} AND user_id IS NOT NULL'
    lyr = QgsVectorLayer(uri, "vn_other", "postgres")
    proj.addMapLayer(lyr, False)
    parent_grp = root.findGroup("vn")
    node = parent_grp.addLayer(lyr)
    node.setItemVisibilityChecked(False)
    lyr.loadNamedStyle(f"{STYLE_PATH}vn_other.qml")

    # ================= vn_null
    uri = f'{PARAMS} table="team_{dlg.team_i}"."team_viewnet" (geom) sql=user_id IS NULL'
    lyr = QgsVectorLayer(uri, "vn_null", "postgres")
    proj.addMapLayer(lyr, False)
    parent_grp = root.findGroup("vn")
    node = parent_grp.addLayer(lyr)
    node.setItemVisibilityChecked(False)
    lyr.loadNamedStyle(f"{STYLE_PATH}vn_null.qml")

    # ================= vn_all
    uri = f'{PARAMS} table="team_{dlg.team_i}"."team_viewnet" (geom) sql='
    lyr = QgsVectorLayer(uri, "vn_all", "postgres")
    proj.addMapLayer(lyr, False)
    parent_grp = root.findGroup("vn")
    node = parent_grp.addLayer(lyr)
    node.setItemVisibilityChecked(False)
    lyr.loadNamedStyle(f"{STYLE_PATH}vn_all.qml")

    # ================= powiaty_mask
    uri = f'?query=Select st_union(geometry) from powiaty'
    lyr = QgsVectorLayer(uri, "powiaty_mask", "virtual")
    proj.addMapLayer(lyr, False)
    parent_grp = root
    parent_grp.insertChildNode(6, QgsLayerTreeLayer(lyr))
    parent_grp.findLayer(lyr).setItemVisibilityChecked(True)
    lyr.loadNamedStyle(f"{STYLE_PATH}powiaty_mask.qml")

    # ================= midas_zloza
    uri = f'{PARAMS} table="external"."midas_zloza" (geom) sql='
    lyr = QgsVectorLayer(uri, "midas_zloza", "postgres")
    proj.addMapLayer(lyr, False)
    parent_grp = root.findGroup("MIDAS")
    node = parent_grp.addLayer(lyr)
    node.setItemVisibilityChecked(True)
    lyr.loadNamedStyle(f"{STYLE_PATH}midas_zloza.qml")

    # ================= midas_wybilansowane
    uri = f'{PARAMS} table="external"."midas_wybilansowane" (geom) sql='
    lyr = QgsVectorLayer(uri, "midas_wybilansowane", "postgres")
    proj.addMapLayer(lyr, False)
    parent_grp = root.findGroup("MIDAS")
    node = parent_grp.addLayer(lyr)
    node.setItemVisibilityChecked(True)
    lyr.loadNamedStyle(f"{STYLE_PATH}midas_wybilansowane.qml")

    # ================= midas_obszary
    uri = f'{PARAMS} table="external"."midas_obszary" (geom) sql='
    lyr = QgsVectorLayer(uri, "midas_obszary", "postgres")
    proj.addMapLayer(lyr, False)
    parent_grp = root.findGroup("MIDAS")
    node = parent_grp.addLayer(lyr)
    node.setItemVisibilityChecked(True)
    lyr.loadNamedStyle(f"{STYLE_PATH}midas_obszary.qml")

    # ================= midas_tereny
    uri = f'{PARAMS} table="external"."midas_tereny" (geom) sql='
    lyr = QgsVectorLayer(uri, "midas_tereny", "postgres")
    proj.addMapLayer(lyr, False)
    parent_grp = root.findGroup("MIDAS")
    node = parent_grp.addLayer(lyr)
    node.setItemVisibilityChecked(True)
    lyr.loadNamedStyle(f"{STYLE_PATH}midas_tereny.qml")

    # ================= mgsp_pkt_kop
    uri = f'{PARAMS} table="external"."mgsp_pkt_kop" (geom) sql='
    lyr = QgsVectorLayer(uri, "mgsp_pkt_kop", "postgres")
    proj.addMapLayer(lyr, False)
    parent_grp = root.findGroup("MGSP")
    node = parent_grp.addLayer(lyr)
    node.setItemVisibilityChecked(True)
    lyr.loadNamedStyle(f"{STYLE_PATH}mgsp_pkt_kop.qml")

    # ================= mgsp_zloza_p
    uri = f'{PARAMS} table="external"."mgsp_zloza_p" (geom) sql='
    lyr = QgsVectorLayer(uri, "mgsp_zloza_p", "postgres")
    proj.addMapLayer(lyr, False)
    parent_grp = root.findGroup("MGSP")
    node = parent_grp.addLayer(lyr)
    node.setItemVisibilityChecked(True)
    lyr.loadNamedStyle(f"{STYLE_PATH}mgsp_zloza_p.qml")

    # ================= mgsp_zloza_a
    uri = f'{PARAMS} table="external"."mgsp_zloza_a" (geom) sql='
    lyr = QgsVectorLayer(uri, "mgsp_zloza_a", "postgres")
    proj.addMapLayer(lyr, False)
    parent_grp = root.findGroup("MGSP")
    node = parent_grp.addLayer(lyr)
    node.setItemVisibilityChecked(True)
    lyr.loadNamedStyle(f"{STYLE_PATH}mgsp_zloza_a.qml")

    # ================= mgsp_zloza_wb_p
    uri = f'{PARAMS} table="external"."mgsp_zloza_wb_p" (geom) sql='
    lyr = QgsVectorLayer(uri, "mgsp_zloza_wb_p", "postgres")
    proj.addMapLayer(lyr, False)
    parent_grp = root.findGroup("MGSP")
    node = parent_grp.addLayer(lyr)
    node.setItemVisibilityChecked(True)
    lyr.loadNamedStyle(f"{STYLE_PATH}mgsp_zloza_wb_p.qml")

    # ================= mgsp_zloza_wb_a
    uri = f'{PARAMS} table="external"."mgsp_zloza_wb_a" (geom) sql='
    lyr = QgsVectorLayer(uri, "mgsp_zloza_wb_a", "postgres")
    proj.addMapLayer(lyr, False)
    parent_grp = root.findGroup("MGSP")
    node = parent_grp.addLayer(lyr)
    node.setItemVisibilityChecked(True)
    lyr.loadNamedStyle(f"{STYLE_PATH}mgsp_zloza_wb_a.qml")

    # ================= smgp_wyrobiska
    uri = f'{PARAMS} table="external"."smgp_wyrobiska" (geom) sql='
    lyr = QgsVectorLayer(uri, "smgp_wyrobiska", "postgres")
    proj.addMapLayer(lyr, False)
    parent_grp = root
    parent_grp.insertChildNode(9, QgsLayerTreeLayer(lyr))
    parent_grp.findLayer(lyr).setItemVisibilityChecked(True)
    node.setItemVisibilityChecked(True)
    lyr.loadNamedStyle(f"{STYLE_PATH}smgp_wyrobiska.qml")


    uri = "crs=EPSG:3857&format&type=xyz&url=https://mt1.google.com/vt/lyrs%3Ds%26x%3D%7Bx%7D%26y%3D%7By%7D%26z%3D%7Bz%7D&zmax=18&zmin=0"
    lyr = QgsRasterLayer(uri, "Google Satellite", "wms")
    if not lyr.isValid():
        print("Layer failed to load!")
        return
    proj.addMapLayer(lyr, False)
    parent_grp = root.findGroup("sat")
    node = parent_grp.addLayer(lyr)
    node.setItemVisibilityChecked(True)
    lyr.loadNamedStyle(f"{STYLE_PATH}google satellite.qml")

    uri = "crs=EPSG:3857&format&tilePixelRatio=2&type=xyz&url=http://mt0.google.com/vt/lyrs%3Dy%26hl%3Den%26x%3D%7Bx%7D%26y%3D%7By%7D%26z%3D%7Bz%7D&zmax=18&zmin=0"
    lyr = QgsRasterLayer(uri, "Google Hybrid", "wms")
    if not lyr.isValid():
        print("Layer failed to load!")
        return
    proj.addMapLayer(lyr, False)
    parent_grp = root.findGroup("sat")
    node = parent_grp.addLayer(lyr)
    node.setItemVisibilityChecked(False)
    lyr.loadNamedStyle(f"{STYLE_PATH}google hybrid.qml")

    uri = "crs=EPSG:2180&dpiMode=0&featureCount=10&format=image/jpeg&layers=ORTOFOTOMAPA&styles=default&tileMatrixSet=EPSG:2180&url=https://mapy.geoportal.gov.pl/wss/service/WMTS/guest/wmts/ORTO?service%3DWMTS%26request%3DgetCapabilities"
    lyr = QgsRasterLayer(uri, "Geoportal", "wms")
    if not lyr.isValid():
        print("Layer failed to load!")
        return
    proj.addMapLayer(lyr, False)
    parent_grp = root.findGroup("sat")
    node = parent_grp.addLayer(lyr)
    node.setItemVisibilityChecked(False)
    lyr.loadNamedStyle(f"{STYLE_PATH}geoportal.qml")

    uri = "crs=EPSG:2180&dpiMode=0&featureCount=10&format=image/jpeg&layers=ORTOFOTOMAPA&styles=default&tileMatrixSet=EPSG:2180&url=https://mapy.geoportal.gov.pl/wss/service/PZGIK/ORTO/WMTS/HighResolution?service%3DWMTS%26request%3DgetCapabilities"
    lyr = QgsRasterLayer(uri, "Geoportal HD", "wms")
    if not lyr.isValid():
        print("Layer failed to load!")
        return
    proj.addMapLayer(lyr, False)
    parent_grp = root.findGroup("sat")
    node = parent_grp.addLayer(lyr)
    node.setItemVisibilityChecked(False)
    lyr.loadNamedStyle(f"{STYLE_PATH}geoportal hd.qml")

    uri = f"{UI_PATH}ge.jpg"
    lyr = QgsRasterLayer(uri, "Google Earth Pro", "gdal")
    lyr.setCrs(CRS_1992)
    if not lyr.isValid():
        print("Layer failed to load!")
        return
    proj.addMapLayer(lyr, False)
    parent_grp = root.findGroup("sat")
    node = parent_grp.addLayer(lyr)
    node.setItemVisibilityChecked(False)
    lyr.loadNamedStyle(f"{STYLE_PATH}google earth pro.qml")

    uri = "crs=EPSG:3857&format&type=xyz&url=https://mt1.google.com/vt/lyrs%3Dm%26x%3D%7Bx%7D%26y%3D%7By%7D%26z%3D%7Bz%7D&zmax=18&zmin=0"
    lyr = QgsRasterLayer(uri, "Google Map", "wms")
    if not lyr.isValid():
        print("Layer failed to load!")
        return
    proj.addMapLayer(lyr, False)
    parent_grp = root.findGroup("topo")
    node = parent_grp.addLayer(lyr)
    node.setItemVisibilityChecked(False)
    lyr.loadNamedStyle(f"{STYLE_PATH}google map.qml")

    uri = "crs=EPSG:3857&format&type=xyz&url=https://tile.openstreetmap.org/%7Bz%7D/%7Bx%7D/%7By%7D.png&zmax=19&zmin=0"
    lyr = QgsRasterLayer(uri, "OpenStreetMap", "wms")
    if not lyr.isValid():
        print("Layer failed to load!")
        return
    proj.addMapLayer(lyr, False)
    parent_grp = root.findGroup("topo")
    node = parent_grp.addLayer(lyr)
    node.setItemVisibilityChecked(False)
    lyr.loadNamedStyle(f"{STYLE_PATH}openstreetmap.qml")

    uri = "crs=EPSG:2180&dpiMode=0&featureCount=10&format=image/jpeg&layers=MAPA TOPOGRAFICZNA&styles=default&tileMatrixSet=EPSG:2180&url=https://mapy.geoportal.gov.pl/wss/service/WMTS/guest/wmts/TOPO?service%3DWMTS%26request%3DgetCapabilities"
    lyr = QgsRasterLayer(uri, "Topograficzna", "wms")
    if not lyr.isValid():
        print("Layer failed to load!")
        return
    proj.addMapLayer(lyr, False)
    parent_grp = root.findGroup("topo")
    node = parent_grp.addLayer(lyr)
    node.setItemVisibilityChecked(False)
    lyr.loadNamedStyle(f"{STYLE_PATH}topograficzna.qml")

    uri = "crs=EPSG:2180&dpiMode=0&featureCount=10&format=image/png&layers=BDOT10k&styles=default&tileMatrixSet=EPSG:2180&url=https://mapy.geoportal.gov.pl/wss/service/WMTS/guest/wmts/BDOT10k?service%3DWMTS%26request%3DgetCapabilities"
    lyr = QgsRasterLayer(uri, "BDOT", "wms")
    if not lyr.isValid():
        print("Layer failed to load!")
        return
    proj.addMapLayer(lyr, False)
    parent_grp = root.findGroup("topo")
    node = parent_grp.addLayer(lyr)
    node.setItemVisibilityChecked(False)
    lyr.loadNamedStyle(f"{STYLE_PATH}bdot.qml")

    uri = "crs=EPSG:2180&dpiMode=0&featureCount=10&format=image/png&layers=BDOO&styles=default&tileMatrixSet=EPSG:2180&url=https://mapy.geoportal.gov.pl/wss/service/WMTS/guest/wmts/BDOO?service%3DWMTS%26request%3DgetCapabilities"
    lyr = QgsRasterLayer(uri, "BDOO", "wms")
    if not lyr.isValid():
        print("Layer failed to load!")
        return
    proj.addMapLayer(lyr, False)
    parent_grp = root.findGroup("topo")
    node = parent_grp.addLayer(lyr)
    node.setItemVisibilityChecked(False)
    lyr.loadNamedStyle(f"{STYLE_PATH}bdoo.qml")
    if not lyr.isValid():
        print("Layer failed to load!")
        return

    # ================= ISOK
    uri = "crs=EPSG:2180&dpiMode=0&featureCount=10&format=image/jpeg&layers=ISOK_Cien&styles=default&tileMatrixSet=EPSG:2180&url=https://mapy.geoportal.gov.pl/wss/service/PZGIK/NMT/GRID1/WMTS/ShadedRelief?service%3DWMTS%26request%3DgetCapabilities"
    lyr = QgsRasterLayer(uri, "ISOK", "wms")
    if not lyr.isValid():
        print("Layer failed to load!")
        return
    proj.addMapLayer(lyr, False)
    parent_grp = root.findGroup("basemaps")
    parent_grp.insertChildNode(0, QgsLayerTreeLayer(lyr))
    parent_grp.findLayer(lyr).setItemVisibilityChecked(False)
    lyr.loadNamedStyle(f"{STYLE_PATH}isok.qml")

    # ================= edit_poly
    lyr = QgsVectorLayer(uri_pg, "edit_poly", "memory")
    lyr.setCustomProperty("skipMemoryLayersCheck", 1)
    pr = lyr.dataProvider()
    pr.addAttributes([
                    QgsField('part', QVariant.Int)
                    ])
    lyr.updateFields()
    proj.addMapLayer(lyr, False)
    parent_grp = root.findGroup("temp")
    node = parent_grp.addLayer(lyr)
    node.setItemVisibilityChecked(True)
    lyr.loadNamedStyle(f"{STYLE_PATH}edit_poly.qml")

    # ================= backup_poly
    lyr = QgsVectorLayer(uri_pg, "backup_poly", "memory")
    lyr.setCustomProperty("skipMemoryLayersCheck", 1)
    pr = lyr.dataProvider()
    pr.addAttributes([
                    QgsField('part', QVariant.Int)
                    ])
    lyr.updateFields()
    proj.addMapLayer(lyr, False)
    parent_grp = root.findGroup("temp")
    node = parent_grp.addLayer(lyr)
    node.setItemVisibilityChecked(False)
    lyr.loadNamedStyle(f"{STYLE_PATH}backup_poly.qml")

        lyrs = [
        {"source": "postgres", "name": "wyr_point", "root": False, "parent": "wyrobiska", "visible": True, "uri": '{PARAMS} table="team_{dlg.team_i}"."wyrobiska" (centroid) sql=wyr_id = 0'},
        {"source": "postgres", "name": "wyr_poly", "root": False, "parent": "wyrobiska", "visible": True, "uri": '{PARAMS} table="team_{dlg.team_i}"."wyr_geom" (geom) sql=wyr_id = 0'},
        {"source": "postgres", "name": "flagi_z_teren", "root": False, "parent": "flagi", "visible": True, "uri": '{PARAMS} table="team_{dlg.team_i}"."flagi" (geom) sql=b_fieldcheck = True'},
        {"source": "postgres", "name": "flagi_bez_teren", "root": False, "parent": "flagi", "visible": True, "uri": '{PARAMS} table="team_{dlg.team_i}"."flagi" (geom) sql=b_fieldcheck = False'},
        {"source": "postgres", "name": "wn_kopaliny_pne", "root": True, "pos": 2, "visible": True, "uri": '{PARAMS} table="external"."wn_kopaliny_pne" (geom) sql='},
        {"source": "postgres", "name": "powiaty", "root": True, "pos": 3, "visible": True, "uri": '{PARAMS} table="team_{dlg.team_i}"."powiaty" (geom) sql='},
        {"source": "postgres", "name": "arkusze", "root": True, "pos": 4, "visible": True, "uri": '{PARAMS} table="team_{dlg.team_i}"."arkusze" (geom) sql='},
        {"source": "postgres", "name": "vn_sel", "root": False, "parent": "vn", "visible": True, "uri": '{PARAMS} table="team_{dlg.team_i}"."team_viewnet" (geom) sql=user_id = {dlg.user_id} AND b_sel IS TRUE'},
        {"source": "postgres", "name": "vn_user", "root": False, "parent": "vn", "visible": True, "uri": '{PARAMS} table="team_{dlg.team_i}"."team_viewnet" (geom) sql=user_id = {dlg.user_id}'},
        {"source": "postgres", "name": "vn_other", "root": False, "parent": "vn", "visible": False, "uri": '{PARAMS} table="team_{dlg.team_i}"."team_viewnet" (geom) sql=user_id <> {dlg.user_id} AND user_id IS NOT NULL'},
        {"source": "postgres", "name": "vn_null", "root": False, "parent": "vn", "visible": False, "uri": '{PARAMS} table="team_{dlg.team_i}"."team_viewnet" (geom) sql=user_id IS NULL'},
        {"source": "postgres", "name": "vn_all", "root": False, "parent": "vn", "visible": False, "uri": '{PARAMS} table="team_{dlg.team_i}"."team_viewnet" (geom) sql='},
        {"source": "virtual", "name": "powiaty_mask", "root": True, "pos": 6, "visible": True, "uri": '?query=Select st_union(geometry) from powiaty'},
        {"source": "postgres", "name": "midas_zloza", "root": False, "parent": "MIDAS", "visible": True, "uri": '{PARAMS} table="external"."midas_zloza" (geom) sql='},
        {"source": "postgres", "name": "midas_wybilansowane", "root": False, "parent": "MIDAS", "visible": True, "uri": '{PARAMS} table="external"."midas_wybilansowane" (geom) sql='},
        {"source": "postgres", "name": "midas_obszary", "root": False, "parent": "MIDAS", "visible": True, "uri": '{PARAMS} table="external"."midas_obszary" (geom) sql='},
        {"source": "postgres", "name": "midas_tereny", "root": False, "parent": "MIDAS", "visible": True, "uri": '{PARAMS} table="external"."midas_tereny" (geom) sql='},
        {"source": "postgres", "name": "mgsp_pkt_kop", "root": False, "parent": "MGSP", "visible": True, "uri": '{PARAMS} table="external"."mgsp_pkt_kop" (geom) sql='},
        {"source": "postgres", "name": "mgsp_zloza_p", "root": False, "parent": "MGSP", "visible": True, "uri": '{PARAMS} table="external"."mgsp_zloza_p" (geom) sql='},
        {"source": "postgres", "name": "mgsp_zloza_a", "root": False, "parent": "MGSP", "visible": True, "uri": '{PARAMS} table="external"."mgsp_zloza_a" (geom) sql='},
        {"source": "postgres", "name": "mgsp_zloza_wb_p", "root": False, "parent": "MGSP", "visible": True, "uri": '{PARAMS} table="external"."mgsp_zloza_wb_p" (geom) sql='},
        {"source": "postgres", "name": "mgsp_zloza_wb_a", "root": False, "parent": "MGSP", "visible": True, "uri": '{PARAMS} table="external"."mgsp_zloza_wb_a" (geom) sql='},
        {"source": "postgres", "name": "smgp_wyrobiska", "root": True, "pos": 9, "visible": True, "uri": '{PARAMS} table="external"."smgp_wyrobiska" (geom) sql='},
        {"source": "wms", "name": "Google Satellite", "root": False, "parent": "sat", "visible": True, "uri": 'crs=EPSG:3857&format&type=xyz&url=https://mt1.google.com/vt/lyrs%3Ds%26x%3D%7Bx%7D%26y%3D%7By%7D%26z%3D%7Bz%7D&zmax=18&zmin=0'},
        {"source": "wms", "name": "Google Hybrid", "root": False, "parent": "sat", "visible": False, "uri": 'crs=EPSG:3857&format&tilePixelRatio=2&type=xyz&url=http://mt0.google.com/vt/lyrs%3Dy%26hl%3Den%26x%3D%7Bx%7D%26y%3D%7By%7D%26z%3D%7Bz%7D&zmax=18&zmin=0'},
        {"source": "wms", "name": "Geoportal", "root": False, "parent": "sat", "visible": False, "uri": 'crs=EPSG:2180&dpiMode=0&featureCount=10&format=image/jpeg&layers=ORTOFOTOMAPA&styles=default&tileMatrixSet=EPSG:2180&url=https://mapy.geoportal.gov.pl/wss/service/WMTS/guest/wmts/ORTO?service%3DWMTS%26request%3DgetCapabilities'},
        {"source": "wms", "name": "Geoportal HD", "root": False, "parent": "sat", "visible": False, "uri": 'crs=EPSG:2180&dpiMode=0&featureCount=10&format=image/jpeg&layers=ORTOFOTOMAPA&styles=default&tileMatrixSet=EPSG:2180&url=https://mapy.geoportal.gov.pl/wss/service/PZGIK/ORTO/WMTS/HighResolution?service%3DWMTS%26request%3DgetCapabilities'},
        {"source": "gdal", "name": "Google Earth Pro", "root": False, "parent": "sat", "visible": False, "uri": '{UI_PATH}ge.jpg'},
        {"source": "wms", "name": "Google Map", "root": False, "parent": "topo", "visible": False, "uri": 'crs=EPSG:3857&format&type=xyz&url=https://mt1.google.com/vt/lyrs%3Dm%26x%3D%7Bx%7D%26y%3D%7By%7D%26z%3D%7Bz%7D&zmax=18&zmin=0'},
        {"source": "wms", "name": "OpenStreetMap", "root": False, "parent": "topo", "visible": False, "uri": 'crs=EPSG:3857&format&type=xyz&url=https://tile.openstreetmap.org/%7Bz%7D/%7Bx%7D/%7By%7D.png&zmax=19&zmin=0'},
        {"source": "wms", "name": "Topograficzna", "root": False, "parent": "topo", "visible": False, "uri": 'crs=EPSG:2180&dpiMode=0&featureCount=10&format=image/jpeg&layers=MAPA TOPOGRAFICZNA&styles=default&tileMatrixSet=EPSG:2180&url=https://mapy.geoportal.gov.pl/wss/service/WMTS/guest/wmts/TOPO?service%3DWMTS%26request%3DgetCapabilities'},
        {"source": "wms", "name": "BDOT", "root": False, "parent": "topo", "visible": False, "uri": 'crs=EPSG:2180&dpiMode=0&featureCount=10&format=image/png&layers=BDOT10k&styles=default&tileMatrixSet=EPSG:2180&url=https://mapy.geoportal.gov.pl/wss/service/WMTS/guest/wmts/BDOT10k?service%3DWMTS%26request%3DgetCapabilities'},
        {"source": "wms", "name": "BDOO", "root": False, "parent": "topo", "visible": False, "uri": 'crs=EPSG:2180&dpiMode=0&featureCount=10&format=image/png&layers=BDOO&styles=default&tileMatrixSet=EPSG:2180&url=https://mapy.geoportal.gov.pl/wss/service/WMTS/guest/wmts/BDOO?service%3DWMTS%26request%3DgetCapabilities'},
        {"source": "wms", "name": "ISOK", "root": False, "parent": "basemaps", "pos": 0, "visible": False, "uri": 'crs=EPSG:2180&dpiMode=0&featureCount=10&format=image/jpeg&layers=ISOK_Cien&styles=default&tileMatrixSet=EPSG:2180&url=https://mapy.geoportal.gov.pl/wss/service/PZGIK/NMT/GRID1/WMTS/ShadedRelief?service%3DWMTS%26request%3DgetCapabilities'},
        {"source": "memory", "name": "edit_poly", "root": False, "parent": "temp", "visible": True, "uri": "Polygon?crs=epsg:2180&field=id:integer", "attrib": [QgsField('part', QVariant.Int)]},
        {"source": "memory", "name": "backup_poly", "root": False, "parent": "temp", "visible": False, "uri": "Polygon?crs=epsg:2180&field=id:integer", "attrib": [QgsField('part', QVariant.Int)]}
        ]

            self.back_to_main = run_in_main_thread(self.get_back_to_main)
            # Odpalenie funkcji w wątku pobocznym:
            # t = Thread(target=self.run_in_thread)
            # t.start()
            self.run_in_thread()
            self.get_back_to_main()

    def run_in_thread(self):
        """Odpala funkcję tworzenia projektu i wraca do wątku głównego."""
        create_qgis_project()
        # self.back_to_main()

    def get_back_to_main(self):
        """Odpala w wątku głównym funkcje kończące ładowanie wtyczki."""
        self.dockwidget.ge = GESync()  # Integracja z Google Earth Pro
        teams_cb_changed()  # Załadowanie powiatów
        basemaps_load()  # Załadowanie podkładów mapowych
        sequences_load()
        # show the dockwidget
        # TODO: fix to allow choice of dock location
        self.iface.addDockWidget(Qt.LeftDockWidgetArea, self.dockwidget)
        self.dockwidget.obj.init_void = False  # Odblokowanie ObjectManager'a
        self.dockwidget.ext_init()
        self.dockwidget.side_dock.show()
        self.dockwidget.mt.init("multi_tool")
        self.dockwidget.show()
        # self.dockwidget.splash_screen.hide()
        finish = time.perf_counter()
        print(f"Proces ładowania pluginu trwał {round(finish - self.start, 2)} sek.")
        # self.dockwidget.setUpdatesEnabled(True)
        # QgsProject.instance().layerTreeRoot().setUpdatesEnabled(True)
