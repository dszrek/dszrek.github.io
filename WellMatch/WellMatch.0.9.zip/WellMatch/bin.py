# type: ignore

class TableView(QTableView):
    def __init__(self):
        QTableView.__init__(self)

    def resizeEvent(self, event):
        """ Resize all sections to content and user interactive """
        super().resizeEvent(event)
        header = self.horizontalHeader()
        for column in range(header.count()):
            header.setSectionResizeMode(column, QHeaderView.ResizeToContents)
            width = header.sectionSize(column)
            header.setSectionResizeMode(column, QHeaderView.Interactive)
            header.resizeSection(column, width)

class HeaderView(QHeaderView):
    def __init__(self, parent):
        QHeaderView.__init__(self, Qt.Horizontal, parent)
        self.sectionResized.connect(self.myresize)

    def myresize(self, *args):
        '''Resize while keep total width constant'''
        # keep a copy of column widths
        ws=[]
        for c in range(self.count()):
            wii=self.sectionSize(c)
            ws.append(wii)

        if args[0]>0 or args[0]<self.count():
            for ii in range(args[0], self.count()):
                if ii==args[0]:
                    # resize present column
                    self.resizeSection(ii, args[2])
                elif ii==args[0]+1:
                    # if present column expands, shrink the one to the right
                    self.resizeSection(ii, ws[ii]-(args[2]-args[1]))
                else:
                    # keep all others as they were
                    self.resizeSection(ii, ws[ii])

    def resizeEvent(self, event):
        """Resize table as a whole, need this to enable resizing"""
        super(QHeaderView, self).resizeEvent(event)
        self.setSectionResizeMode(1, QHeaderView.Stretch)
        for column in range(self.count()):
            self.setSectionResizeMode(column, QHeaderView.Stretch)
            width = self.sectionSize(column)
            self.setSectionResizeMode(column, QHeaderView.Interactive)
            self.resizeSection(column, width)
        return



xt = pd.read_csv("D:/warsztat/well_matching/test/og_full.csv", error_bad_lines=False, encoding="windows 1250", delimiter=";")
xt.columns = ['ID', 'NAZWA', 'X', 'Y', 'Z', 'H', 'ROK', 'SKAN', 'TRANS']

# self.pdtable = QTableView()
# sizePolicy = QSizePolicy(QSizePolicy.MinimumExpanding, QSizePolicy.MinimumExpanding)
# self.pdtable.setSizePolicy(sizePolicy)
self.model = DataFrameModel(xt)
self.pdtable.setModel(self.model)
self.pdtable.horizontalHeader().setMinimumSectionSize(1)
self.pdtable.setColumnWidth(0, 100)
self.pdtable.setColumnWidth(1, 270)
self.pdtable.setColumnWidth(2, 60)
self.pdtable.setColumnWidth(3, 60)
self.pdtable.setColumnWidth(4, 50)
self.pdtable.setColumnWidth(5, 50)
self.pdtable.setColumnWidth(6, 50)
self.pdtable.setColumnWidth(7, 50)
self.pdtable.setColumnWidth(8, 50)

# hv = HeaderView(self.frm_main)
# self.pdtable.setHorizontalHeader(hv)

self.vl_main.addWidget(self.pdtable)
self.frm_main.setLayout(self.vl_main)


# print(self.valid['Z'].dtypes)
# self.valid['Z'] = pd.to_numeric(self.valid['Z'], errors='coerce')
# self.valid['Z'].astype(float).applymap('{:,.2f}'.format))

#blue:
QPushButton {
border-radius: 4px;
border: 1px solid rgb(1,87,155);
padding: 12px;
color: black;
font-size: 12px;
font-weight: normal
}

QPushButton:pressed {
background-color: rgb(2,136,209)
}

QPushButton:enabled {
background-color: rgb(3,169,244)
}

QPushButton:disabled {
color: white;
background-color: rgb(179,229,252);
border: 1px solid white
}

QPushButton:hover {
background-color: rgb(79,195,247)
}

QPushButton:checked {
background-color: rgb(2,136,209);
color: white;
border: 2px solid white
}

#red:
QPushButton {
border-radius: 4px;
border: 1px solid rgb(183,28,28);
padding: 12px;
color: black;
font-size: 12px;
font-weight: normal
}

QPushButton:pressed {
background-color: rgb(211,47,47)
}

QPushButton:enabled {
background-color: rgb(244,67,54)
}

QPushButton:disabled {
color: white;
background-color: rgb(255,205,210);
border: 1px solid white
}

QPushButton:hover {
background-color: rgb(229,115,115)
}

QPushButton:checked {
background-color: rgb(211,47,47);
color: white;
border: 2px solid white
}



class MainDataFrame(DataFrameModel):
    """Subklasa DataFrameModel obsługująca dane ze zbioru A lub B."""

    flt_changed = pyqtSignal(str)
    param_changed = pyqtSignal(str)
    bmode_changed = pyqtSignal(bool)
    done_changed = pyqtSignal(bool)

    def __init__(self, df, id, dlg):
        super().__init__(df)
        self.p_cnt = len(df.columns) - 4
        cols = ['ID', 'NAZWA', 'X', 'Y', 'Z', 'H', 'ROK', 'SKAN', 'TRANS']
        df.columns = cols[:self.p_cnt + 4]
        self.dlg = dlg  # Referencja do ui
        # if id == "A":
        #     self = self
        # elif id == "B":
        #     self = self.dlg.bdf
        self.tv = dlg.tv_df  # Referencja do tableview
        self.dlg.tv_df.setModel(self)
        self.tv_format()  # Formatowanie kolumn tableview
        self.bmode = False  # Tryb aktywnego parametru typu boolean
        self.bmode_changed.connect(self.bmode_change)
        self.light = None
        self.btn_ok = self.dlg.btnbx.button(QDialogButtonBox.Ok)
        self.btn_ok.setEnabled(False)
        self.btn_ok.clicked.connect(self.data_export)
        # Wszystkie rekordy:
        self.all = df  # Dataframe
        self.all_cnt = len(self.all)  # Suma rekordów
        # Rekordy z pustym id:
        self.idna = df[df['ID'].isna()]
        self.idna_cnt = int()
        # Rekordy z nieunikalnymi id:
        self.idnu = df[df['ID'].duplicated(keep=False)]
        self.idnu_cnt = int()
        # Rekordy z błędną lokalizacją:
        self.xynv = None
        self.xynv_cnt = int()
        # Prawidłowe rekordy:
        self.valid = None
        self.valid_cnt = int()
        # Przetworzone rekordy:
        self.ready = None
        # Indeksy:
        self.df_in = pd.DataFrame(columns=['ORIGIN','WARTOŚĆ', 'ILOŚĆ'])
        self.df_out = pd.DataFrame(columns=['WARTOŚĆ', 'ILOŚĆ'])
        self.idx_in = IdxDataFrame(self.df_in, self.dlg.tv_idx_in, True, self.dlg, self)
        self.idx_out = IdxDataFrame(self.df_out, self.dlg.tv_idx_out, False, self.dlg, self)
        # Dataframe'y parametrów:
        self.z_in = pd.DataFrame(columns=['ORIGIN', 'WARTOŚĆ', 'ILOŚĆ'])
        self.z_out = pd.DataFrame(columns=['WARTOŚĆ', 'ILOŚĆ'])
        self.h_in = pd.DataFrame(columns=['ORIGIN', 'WARTOŚĆ', 'ILOŚĆ'])
        self.h_out = pd.DataFrame(columns=['WARTOŚĆ', 'ILOŚĆ'])
        self.r_in = pd.DataFrame(columns=['ORIGIN', 'WARTOŚĆ', 'ILOŚĆ'])
        self.r_out = pd.DataFrame(columns=['WARTOŚĆ', 'ILOŚĆ'])
        self.s_in = pd.DataFrame(columns=['ORIGIN', 'WARTOŚĆ', 'ILOŚĆ'])
        self.s_out = pd.DataFrame(columns=['WARTOŚĆ', 'ILOŚĆ'])
        self.t_in = pd.DataFrame(columns=['ORIGIN', 'WARTOŚĆ', 'ILOŚĆ'])
        self.t_out = pd.DataFrame(columns=['WARTOŚĆ', 'ILOŚĆ'])
        # Typy parametrów:
        self.type_in = ""
        self.type_act = ""
        self.type_out = ""
        self.done = False
        self.type_in_z = ""
        self.type_act_z = ""
        self.type_out_z = ""
        self.done_z = False
        self.type_in_h = ""
        self.type_act_h = ""
        self.type_out_h = ""
        self.done_h = False
        self.type_in_r = ""
        self.type_act_r = ""
        self.type_out_r = ""
        self.done_r = False
        self.type_in_s = ""
        self.type_act_s = ""
        self.type_out_s = ""
        self.done_s = False
        self.type_in_t = ""
        self.type_act_t = ""
        self.type_out_t = ""
        self.done_t = False

        all_pbtns = [self.dlg.btn_param_z,
                    self.dlg.btn_param_h,
                    self.dlg.btn_param_r,
                    self.dlg.btn_param_s,
                    self.dlg.btn_param_t]
        self.p_btns = all_pbtns[:self.p_cnt]
        for pbtn in all_pbtns[self.p_cnt:]:
            pbtn.setVisible(False)

        all_lights = [self.dlg.light_z,
                    self.dlg.light_h,
                    self.dlg.light_r,
                    self.dlg.light_s,
                    self.dlg.light_t]
        self.lights = all_lights[:self.p_cnt]
        for light in all_lights[self.p_cnt:]:
            light.setVisible(False)

        all_params = [
            {'param' : 'Z', 'df_in' : self.z_in, 'df_out' : self.z_out, 'type_in' : self.type_in_z, 'type_out' : self.type_out_z, 'type_act' : self.type_act_z, 'done' : self.done_z, 'btn' : self.dlg.btn_param_z, 'light' : self.dlg.light_z},
            {'param' : 'H', 'df_in' : self.h_in, 'df_out' : self.h_out, 'type_in' : self.type_in_h, 'type_out' : self.type_out_h, 'type_act' : self.type_act_h, 'done' : self.done_h, 'btn' : self.dlg.btn_param_h, 'light' : self.dlg.light_h},
            {'param' : 'ROK', 'df_in' : self.r_in, 'df_out' : self.r_out, 'type_in' : self.type_in_r, 'type_out' : self.type_out_r, 'type_act' : self.type_act_r, 'done' : self.done_r, 'btn' : self.dlg.btn_param_r, 'light' : self.dlg.light_r},
            {'param' : 'SKAN', 'df_in' : self.s_in, 'df_out' : self.s_out, 'type_in' : self.type_in_s, 'type_out' : self.type_out_s, 'type_act' : self.type_act_s, 'done' : self.done_s, 'btn' : self.dlg.btn_param_s, 'light' : self.dlg.light_s},
            {'param' : 'TRANS', 'df_in' : self.t_in, 'df_out' : self.t_out, 'type_in' : self.type_in_t, 'type_out' : self.type_out_t, 'type_act' : self.type_act_t, 'done' : self.done_t, 'btn' : self.dlg.btn_param_t, 'light' : self.dlg.light_t}
            ]
        self.params = all_params[:self.p_cnt]

        self.dtypes = [
            {None : ''},
            {'object' : 'tekst'},
            {'Int64' : 'liczba całkowita'},
            {'float64' : 'liczba ułamkowa'},
            {'bool' : 'prawda/fałsz'}
            ]
        self.etypes = [
            {'int32' : 'Int64'},
            {'int64' : 'Int64'}
        ]

        # Populacja combobox'a z oczekiwanymi typami:
        if len(self.dlg.cmb_type) == 0:
            for dtype in self.dtypes:
                for val in dtype.values():
                    self.dlg.cmb_type.addItem(val)
        self.dlg.cmb_type.currentIndexChanged.connect(self.cmb_type_change)

        self.btn_conn()  # Podłączenie funkcji do przycisków
        self.init_validation()  # Walidacja rekordów
        self.param_indexing()  # Indeksacja parametrów
        self.flt_changed.connect(self.flt_change)
        self.flt = "valid"  # Ustawienie aktywnego filtru
        self.param_changed.connect(self.param_change)
        self.old_param = ""
        self.param = "Z"  # Ustawienie aktywnego parametru
        self.done_changed.connect(self.done_change)

    def __setattr__(self, attr, val):
        """Przechwycenie zmiany atrybutu."""
        super().__setattr__(attr, val)
        if attr == "done":
            self.done_changed.emit(val)
        if attr == "bmode":
            self.bmode_changed.emit(val)
        if attr == "flt":
            self.flt_changed.emit(val)
        if attr == "param":
            self.param_changed.emit(val)
        if attr == "all_cnt":
            b_txt = f"Wszystkie \n \n ({val})"
            self.flt_btns_update(self.dlg.btn_flt_all, b_txt, val)
        if attr == "idna_cnt":
            b_txt = f"Brak ID \n \n ({val})"
            self.flt_btns_update(self.dlg.btn_flt_idna, b_txt, val)
        if attr == "idnu_cnt":
            b_txt = f"Nieunikalne ID \n \n ({val})"
            self.flt_btns_update(self.dlg.btn_flt_idnu, b_txt, val)
        if attr == "xynv_cnt":
            b_txt = f"Błędna lokalizacja \n \n ({val})"
            self.flt_btns_update(self.dlg.btn_flt_xynv, b_txt, val)
        if attr == "valid_cnt":
            b_txt = f"Poprawne \n \n ({val})"
            self.flt_btns_update(self.dlg.btn_flt_valid, b_txt, val)
            b_txt = f"Przetworzone \n \n ({val})"
            self.flt_btns_update(self.dlg.btn_flt_ready, b_txt, val)

    def set_flt(self, _flt):
        """Ustawienie nazwy filtru rekordów."""
        self.flt = _flt

    def set_param(self, _param):
        """Ustawienie aktywnego parametru."""
        self.param = _param

    def done_change(self, val):
        """Zmiana atrybutu 'done' aktywnego parametru."""
        if not val:
            # Skasowanie wszystkich zmian w ready:
            self.ready[self.param] = self.valid[self.param]
        self.dlg.btn_bool.setEnabled(not val)
        self.frm_color_update()
        self.btn_ok.setEnabled(True) if self.is_all_done() else self.btn_ok.setEnabled(False)

    def is_all_done(self):
        """Zwraca, czy wszystkie parametry zostały ustalone."""
        for dicts in self.params:
            act = False
            for key, value in dicts.items():
                if key == 'param' and value == self.param:
                    act = True
                if key == 'done':
                    done = value
            if act:
                continue
            if not done:
                return False
        if not self.done:
            return False
        return True

    def bmode_change(self, val):
        """Zmiana trybu aktywnego parametru typu boolean."""
        if val:
            self.dlg.lab_idx_in.setText("Wartości prawdy:")
            self.dlg.lab_idx_out.setText("Wartości fałszu:")
            self.dlg.btn_idx_in.setText("▲     PRAWDA     ▲")
            self.dlg.btn_idx_out.setText("▼        FAŁSZ       ▼")
        else:
            self.dlg.lab_idx_in.setText("Wartości prawidłowe:")
            self.dlg.lab_idx_out.setText("Wartości odrzucone:")
            self.dlg.btn_idx_in.setText("▲   PRZYWRÓĆ   ▲")
            self.dlg.btn_idx_out.setText("▼      ODRZUĆ     ▼")
        self.dlg.h_line.setVisible(not val)
        self.dlg.lab_type_act_title.setVisible(not val)
        self.dlg.lab_type_act.setVisible(not val)
        self.dlg.btn_bool.setVisible(val)

    def flt_change(self, val):
        """Zmiana fitru danych."""
        btns = {'all' : self.dlg.btn_flt_all,
                'idna' : self.dlg.btn_flt_idna,
                'idnu' : self.dlg.btn_flt_idnu,
                'xynv' : self.dlg.btn_flt_xynv,
                'valid' : self.dlg.btn_flt_valid,
                'ready' : self.dlg.btn_flt_ready}
        self.flt_btns_update(btns[val])

    def flt_btns_update(self, _btn):
        """Aktualizacja stanu przycisków filtrujących."""
        btns = {self.dlg.btn_flt_all : self.all,
                self.dlg.btn_flt_idna : self.idna,
                self.dlg.btn_flt_idnu : self.idnu,
                self.dlg.btn_flt_xynv : self.xynv,
                self.dlg.btn_flt_valid : self.valid,
                self.dlg.btn_flt_ready : self.ready}
        for btn, df in btns.items():
            if btn == _btn:
                btn.setChecked(True)
                self.setDataFrame(df)
            else:
                btn.setChecked(False)

    def param_indexing(self):
        """Indeksacja parametrów."""
        for dicts in self.params:
            for key, value in dicts.items():
                if key == 'param':
                    param = value
                elif key == 'df_in':
                    df_in = value
                elif key == 'df_out':
                    df_out = value
                elif key == 'type_in':
                    type_in = value
                elif key == 'type_act':
                    type_act = value
            # Utworzenie dataframe z unikalnymi wartościami parametru:
            idxs = pd.DataFrame(self.valid[param].value_counts())
            idxs.reset_index(inplace=True)
            idxs = idxs.rename(columns = {'index' : 'WARTOŚĆ', param : 'ILOŚĆ'})
            idxs['ORIGIN'] = idxs['WARTOŚĆ']
            idxs = idxs[['ORIGIN', 'WARTOŚĆ', 'ILOŚĆ']]
            idxs = idxs.sort_values(by='WARTOŚĆ').reset_index(drop=True)
            dicts['df_in'] = idxs
            # Zapisanie typu parametru:
            dt = self.valid[param].dtypes
            dt_chk = self.type_desc(dt)
            if not dt_chk:
                et = self.type_conv(dt)
                if et:
                    dt = et
                else:
                    print(f"=====================x-type: {dt} ===============================")
            dicts['type_in'] = dt
            dicts['type_act'] = dt

    def param_change(self, val):
        """Zmiana aktywnego parametru."""
        for dicts in self.params:
            for key, value in dicts.items():
                # Zapisanie zmian w parametrze, który przestaje być aktywny:
                if self.old_param and key == 'param' and value == self.old_param:
                    dicts['df_in'] = self.df_in
                    dicts['df_out'] = self.df_out
                    dicts['type_in'] = self.type_in
                    dicts['type_act'] = self.type_act
                    dicts['type_out'] = self.type_out
                    dicts['done'] = self.done
                    dicts['light'] = self.light
                # Wyszukanie dataframe'ów nowego aktywnego parametru:
                if key == 'param' and value == val:
                    new_in = dicts['df_in']
                    new_out = dicts['df_out']
                    new_type_in = dicts['type_in']
                    new_type_act = dicts['type_act']
                    new_type_out = dicts['type_out']
                    new_done = dicts['done']
                    new_btn = dicts['btn']
                    new_light = dicts['light']
        self.old_param = val
        self.dlg.lab_act_param.setText(val)
        self.param_btns_update(new_btn)
        # Zmiana aktualnych dataframe'ów:
        self.df_in = new_in
        self.df_out = new_out
        self.idx_in.setDataFrame(self.df_in[['WARTOŚĆ', 'ILOŚĆ']])
        self.idx_out.setDataFrame(self.df_out)
        # Zmiana w ustawieniach typu parametru:
        self.type_in = new_type_in
        self.type_act = new_type_act
        self.type_out = new_type_out
        self.dlg.lab_type_in.setText(self.type_desc(self.type_in))
        self.dlg.cmb_type.currentIndexChanged.disconnect(self.cmb_type_change)
        self.dlg.cmb_type.setCurrentText(self.type_desc(self.type_out))
        self.dlg.cmb_type.currentIndexChanged.connect(self.cmb_type_change)
        self.dlg.lab_type_act.setText(self.type_desc(self.type_act))
        self.bmode = True if self.type_out == "bool" else False
        self.light = new_light
        self.done = new_done

    def param_btns_update(self, _btn):
        """Aktualizacja stanu przycisków parametrów."""
        for btn in self.p_btns:
            btn.setChecked(True) if btn == _btn else btn.setChecked(False)

    def flt_btns_state(self, btn, txt, val):
        """Aktualizacja ustawień przycisku filtrującego."""
        is_enabled = True if val > 0 else False
        btn.setText(txt)
        btn.setEnabled(is_enabled)

    def type_desc(self, _type):
        """Zwraca opis wybranego dtypes."""
        _type = str(_type)
        for dicts in self.dtypes:
            for dt, desc in dicts.items():
                if dt == _type:
                    return desc

    def type_name(self, _type):
        """Zwraca nazwę wybranego dtypes."""
        _type = str(_type)
        for dicts in self.dtypes:
            for dt, desc in dicts.items():
                if desc == _type:
                    return dt

    def type_conv(self, _type):
        """Konwertuje wybrany dtypes do podstawowego."""
        _type = str(_type)
        for dicts in self.etypes:
            for dt, et in dicts.items():
                if dt == _type:
                    return et

    def cmb_type_change(self):
        """Zmiana wartości w combobox'ie act_type."""
        type_txt = self.dlg.cmb_type.currentText()
        self.type_out = self.type_name(type_txt)
        if type_txt == "":
            self.type_out = "object"
        if type_txt == "prawda/fałsz":
            self.bmode = True
            self.done = False
        else:
            self.bmode = False
            self.ready_set_nan()
            self.type_change()

    def type_change(self):
        """Próba zmiany typu kolumny w dataframe 'ready'."""
        if not self.bmode:
            self.done = True
            try:
                self.ready[self.param] = self.ready[self.param].astype('float').astype(self.type_out)
                self.df_in['WARTOŚĆ'] = self.df_in['WARTOŚĆ'].astype('float').astype(self.type_out)
            except Exception as error:
                self.done = False
                print(error)
        self.type_act = self.ready[self.param].dtypes
        self.dlg.lab_type_act.setText(self.type_desc(self.type_act))
        try:
            # Próba sortowania liczbowego:
            a = self.df_in['WARTOŚĆ'].astype(float).argsort()
            self.df_in = pd.DataFrame(self.df_in.values[a], self.df_in.index[a], self.df_in.columns).reset_index(drop=True)
        except:
            # Sortowanie tekstowe:
            a = self.df_in['WARTOŚĆ'].astype(str).argsort()
            self.df_in = pd.DataFrame(self.df_in.values[a], self.df_in.index[a], self.df_in.columns).reset_index(drop=True)
        self.idx_in.setDataFrame(self.df_in[['WARTOŚĆ', 'ILOŚĆ']])

    def frm_color_update(self):
        """Zarządzanie kolorem ramki typów."""
        frm_red = """QFrame #frm_param_type {
                border-radius: 4px;
                border: 1px solid white;
                background-color: rgb(248,173,173)
            }"""
        frm_green = """QFrame #frm_param_type {
                border-radius: 4px;
                border: 1px solid white;
                background-color: rgb(198,224,180)
            }"""
        led_red = """QFrame {
                border-radius: 4px;
                border: 1px solid grey;
                background-color: rgb(248,173,173)
            }"""
        led_green = """QFrame {
                border-radius: 4px;
                border: 1px solid grey;
                background-color: rgb(198,224,180)
            }"""
        self.dlg.frm_param_type.setStyleSheet(frm_green) if self.done else self.dlg.frm_param_type.setStyleSheet(frm_red)
        self.light.setStyleSheet(led_green) if self.done else self.light.setStyleSheet(led_red)

    def index_move(self, direction):
        """Przeniesienie rekordu indeksu z tabeli indeksów ustalonych do odrzuconych lub na odwrót."""
        if self.done:
            self.done = False
        if direction == "down":
            self.df_in['ILOŚĆ'] = self.df_in['ILOŚĆ'].astype('object')
            _from = self.idx_in
            df_from = self.df_in
            _to = self.idx_out
            df_to = self.df_out
        elif direction == "up":
            self.df_in['WARTOŚĆ'] = self.df_in['WARTOŚĆ'].astype('object')
            _from = self.idx_out
            df_from = self.df_out
            _to = self.idx_in
            df_to = self.df_in
        idx_row = _from.sel_tv.currentIndex().row()
        if idx_row < 0:  # Brak zaznaczonego wiersza
            return
        sel_row = df_from[df_from.index == idx_row]
        if direction == "down":
            sel_row = sel_row[['ORIGIN', 'ILOŚĆ']].rename(columns = {'ORIGIN' : 'WARTOŚĆ'})
        elif direction == "up":
            sel_row['ORIGIN'] = sel_row['WARTOŚĆ']
            sel_row = sel_row[['ORIGIN', 'WARTOŚĆ', 'ILOŚĆ']]
        df_to = df_to.append(sel_row, ignore_index=True)
        if len(df_from) > 1:
            try:
                # Próba sortowania liczbowego:
                a = df_from['WARTOŚĆ'].astype(float).argsort()
                df_from = pd.DataFrame(df_from.values[a], df_from.index[a], df_from.columns).reset_index(drop=True)
            except:
                # Sortowanie tekstowe:
                a = df_from['WARTOŚĆ'].astype(str).argsort()
                df_from = pd.DataFrame(df_from.values[a], df_from.index[a], df_from.columns).reset_index(drop=True)
        if len(df_to) > 1:
            try:
                # Próba sortowania liczbowego:
                a = df_to['WARTOŚĆ'].astype(float).argsort()
                df_to = pd.DataFrame(df_to.values[a], df_to.index[a], df_to.columns).reset_index(drop=True)
            except:
                # Sortowanie tekstowe:
                a = df_to['WARTOŚĆ'].astype(str).argsort()
                df_to = pd.DataFrame(df_to.values[a], df_to.index[a], df_to.columns).reset_index(drop=True)
        df_from.drop(sel_row.index, inplace=True)
        df_from = df_from.reset_index(drop=True)
        self.df_in = df_from if direction == "down" else df_to
        self.df_out = df_to if direction == "down" else df_from
        _from.setDataFrame(df_from)
        _to.setDataFrame(df_to)
        if not self.bmode:
            self.ready_set_nan()
        self.type_change()  # Próba zmiany typu kolumny

    def ready_set_nan(self):
        """Aktualizacja wartości NaN w df_ready."""
        # Ustawienie wartości NaN w odpowiednich komórkach:
        out_vals = self.df_out['WARTOŚĆ'].tolist()
        self.ready.loc[self.ready[self.param].isin(out_vals), self.param] = np.nan

    def ready_set_bool(self):
        """Aktualizacja wartości bool w df_ready."""
        self.ready[self.param] = self.ready[self.param].astype('object')
        # Ustawienie wartości boolean w odpowiednich komórkach:
        t_vals = self.df_in['WARTOŚĆ'].tolist()
        f_vals = self.df_out['WARTOŚĆ'].tolist()
        self.ready.loc[self.ready[self.param].isin(t_vals), self.param] = True
        self.ready.loc[self.ready[self.param].isin(f_vals), self.param] = False
        self.ready[self.param].fillna(False, inplace=True)
        self.ready[self.param] = self.ready[self.param].astype('bool')
        self.done = True

    def init_validation(self):
        """Wykrycie błędów związanych z id i współrzędnymi otworów. Selekcja prawidłowych rekordów."""
        idx_nv = pd.DataFrame(columns=['idx'])  # Pusty dataframe do wrzucania indeksów błędnych rekordów
        idx_nv = idx_nv.append(pd.DataFrame(self.idna.rename_axis('idx').reset_index()['idx']), ignore_index=True)
        self.idna = self.idna.reset_index(drop=True)
        self.idna_cnt = len(self.idna)
        idx_nv = idx_nv.append(pd.DataFrame(self.idnu.rename_axis('idx').reset_index()['idx']), ignore_index=True)
        self.idnu = self.idnu.reset_index(drop=True)
        self.idnu_cnt = len(self.idnu)
        bad_x = self.all['X'].isna() | (self.all['X'] < 170000.0) | (self.all['X'] > 870000.0)
        bad_y = self.all['Y'].isna() | (self.all['Y'] < 140000.0) | (self.all['Y'] > 890000.0)
        self.xynv = self.all[ bad_x | bad_y]
        idx_nv = idx_nv.append(pd.DataFrame(self.xynv.rename_axis('idx').reset_index()['idx']), ignore_index=True)
        self.xynv = self.xynv.reset_index(drop=True)
        self.xynv_cnt = len(self.xynv)
        idx_nv.drop_duplicates(keep='first', inplace=True, ignore_index=True)
        self.valid = self.all[~self.all.reset_index().index.isin(idx_nv['idx'])]
        self.valid = self.valid.reset_index(drop=True)
        self.valid_cnt = len(self.valid)
        self.ready = self.valid.copy()

    def tv_format(self):
        """Formatowanie kolumn tableview'u."""
        self.tv.setColumnWidth(0, 100)
        self.tv.setColumnWidth(1, 270)
        self.tv.setColumnWidth(2, 60)
        self.tv.setColumnWidth(3, 60)
        self.tv.setColumnWidth(4, 50)
        self.tv.setColumnWidth(5, 50)
        self.tv.setColumnWidth(6, 50)
        self.tv.setColumnWidth(7, 50)
        self.tv.setColumnWidth(8, 50)
        self.tv.horizontalHeader().setMinimumSectionSize(1)

    def btn_conn(self):
        """Podłączenie funkcji do przycisków."""
        # Filtry:
        self.dlg.btn_flt_all.clicked.connect(lambda: self.set_flt('all'))
        self.dlg.btn_flt_idna.clicked.connect(lambda: self.set_flt('idna'))
        self.dlg.btn_flt_idnu.clicked.connect(lambda: self.set_flt('idnu'))
        self.dlg.btn_flt_xynv.clicked.connect(lambda: self.set_flt('xynv'))
        self.dlg.btn_flt_valid.clicked.connect(lambda: self.set_flt('valid'))
        self.dlg.btn_flt_ready.clicked.connect(lambda: self.set_flt('ready'))
        # Parametry:
        self.dlg.btn_param_z.clicked.connect(lambda: self.set_param('Z'))
        self.dlg.btn_param_h.clicked.connect(lambda: self.set_param('H'))
        self.dlg.btn_param_r.clicked.connect(lambda: self.set_param('ROK'))
        self.dlg.btn_param_s.clicked.connect(lambda: self.set_param('SKAN'))
        self.dlg.btn_param_t.clicked.connect(lambda: self.set_param('TRANS'))
        # Indeksacja:
        self.dlg.btn_idx_out.pressed.connect(lambda: self.index_move('down'))
        self.dlg.btn_idx_in.pressed.connect(lambda: self.index_move('up'))
        # Zatwierdzenie wartości typu boolean:
        self.dlg.btn_bool.pressed.connect(self.ready_set_bool)

    def data_export(self):
        print("end")

class IdxDataFrame(DataFrameModel):
    """Subklasa DataFrameModel obsługująca indeksy wybranego parametru (np. Z)."""
    def __init__(self, df, tv, _in, dlg, _parent):
        super().__init__(df)
        self.df_in = _in
        self.dlg = dlg  # Referencja do ui
        self._parent = _parent
        self.tv = tv  # Referencja do tableview
        self.tv.setModel(self)
        self.tv_format()  # Formatowanie kolumn tableview
        self.sel_tv = self.tv.selectionModel()
        self.sel_tv.selectionChanged.connect(self.show_index_records)

    def sel_idx(self):
        """Zwraca indeks zaznaczonego wiersza z tableview."""
        return self.sel_tv.currentIndex().row()

    def tv_format(self):
        """Formatowanie kolumn tableview'u."""
        self.tv.setColumnWidth(0, 70)
        self.tv.setColumnWidth(1, 50)
        self.tv.horizontalHeader().setMinimumSectionSize(1)

    def show_index_records(self):
        """Pokazanie w tv_df rekordów z parametrem równym wybranemu indeksowi."""
        self._parent.set_flt('valid')  # Przejście do filtru 'valid'
        index = self.sel_tv.currentIndex()
        value = index.sibling(index.row(), 0).data()
        if self.df_in:  # Wartości prawidłowe
            s_df = self.df_in
            value = float(value) if self.type_act == 'float64' or self.type_act == 'Int64' else str(value)
            value = s_df[s_df['WARTOŚĆ'] == value]['ORIGIN'].values[0]
        df = self.valid
        value = str(value) if df[self.param].dtypes == 'object' else float(value)
        df = df[df[self.param] == value].reset_index(drop=True)
        self.setDataFrame(df)


from .models.ColumnDtypeModel import ColumnDtypeModel
from .models.DataSearch import DataSearch
from pandasqt.models.SupportedDtypes import SupportedDtypes

DATAFRAME_ROLE = Qt.UserRole + 2

class DataFrameModel(QAbstractTableModel):
    """data model for use in QTableView, QListView, QComboBox, etc.
    Attributes:
        timestampFormat (unicode): formatting string for conversion of timestamps to QtCore.QDateTime.
            Used in data method.
        sortingAboutToStart (QtCore.pyqtSignal): emitted directly before sorting starts.
        sortingFinished (QtCore.pyqtSignal): emitted, when sorting finished.
        dtypeChanged (Signal(columnName)): passed from related ColumnDtypeModel
            if a columns dtype has changed.
        changingDtypeFailed (Signal(columnName, index, dtype)):
            passed from related ColumnDtypeModel.
            emitted after a column has changed it's data type.
        dataChanged (Signal):
            Emitted, if data has changed, e.x. finished loading, new columns added or removed.
            It's not the same as layoutChanged.
            Usefull to reset delegates in the view.
    """

    _float_precisions = {
        "float16": np.finfo(np.float16).precision - 2,
        "float32": np.finfo(np.float32).precision - 1,
        "float64": np.finfo(np.float64).precision - 1
    }

    """list of int datatypes for easy checking in data() and setData()"""
    _intDtypes = SupportedDtypes.intTypes() + SupportedDtypes.uintTypes()
    """list of float datatypes for easy checking in data() and setData()"""
    _floatDtypes = SupportedDtypes.floatTypes()
    """list of bool datatypes for easy checking in data() and setData()"""
    _boolDtypes = SupportedDtypes.boolTypes()
    """list of datetime datatypes for easy checking in data() and setData()"""
    _dateDtypes = SupportedDtypes.datetimeTypes()

    _timestampFormat = Qt.ISODate

    sortingAboutToStart = pyqtSignal()
    sortingFinished = pyqtSignal()
    dtypeChanged = pyqtSignal(int, object)
    changingDtypeFailed = pyqtSignal(object, QModelIndex, object)
    dataChanged = pyqtSignal()
    dataFrameChanged = pyqtSignal()

    def __init__(self, dataFrame=None, tv=None, col_widths=[], col_names=[], copyDataFrame=False):
        """the __init__ method.
        Args:
            dataFrame (pandas.core.frame.DataFrame, optional): initializes the model with given DataFrame.
                If none is given an empty DataFrame will be set. defaults to None.
            copyDataFrame (bool, optional): create a copy of dataFrame or use it as is. defaults to False.
                If you use it as is, you can change it from outside otherwise you have to reset the dataFrame
                after external changes.
        """
        super(DataFrameModel, self).__init__()

        self._dataFrame = pd.DataFrame()
        if dataFrame is not None:
            self.setDataFrame(dataFrame, copyDataFrame=copyDataFrame)
        self.dataChanged.emit()
        self.col_names = col_names
        self.tv = tv  # Referencja do tableview
        self.tv.setModel(self)
        # self.tv.horizontalHeader().setSortIndicator(-1, Qt.AscendingOrder)
        # self.tv.setSortingEnabled(True)
        self.col_format(col_widths)
        self._dataFrameOriginal = None
        self._search = DataSearch("nothing", "")
        self.editable = False

    def col_format(self, col_widths):
        """Formatowanie szerokości kolumn tableview'u."""
        cols = list(enumerate(col_widths, 0))
        for col in cols:
            self.tv.setColumnWidth(col[0], col[1])
        self.tv.horizontalHeader().setMinimumSectionSize(1)

    def col_names(self, df, col_names):
        """Nadanie nazw kolumn tableview'u."""
        df.columns = col_names
        return df
    def dataFrame(self):
        """getter function to _dataFrame. Holds all data.
        Note:
            It's not implemented with python properties to keep Qt conventions.
        """
        return self._dataFrame

    def setDataFrame(self, dataFrame, copyDataFrame=False):
        """setter function to _dataFrame. Holds all data.
        Note:
            It's not implemented with python properties to keep Qt conventions.
        Raises:
            TypeError: if dataFrame is not of type pandas.core.frame.DataFrame.
        Args:
            dataFrame (pandas.core.frame.DataFrame): assign dataFrame to _dataFrame. Holds all the data displayed.
            copyDataFrame (bool, optional): create a copy of dataFrame or use it as is. defaults to False.
                If you use it as is, you can change it from outside otherwise you have to reset the dataFrame
                after external changes.
        """
        if not isinstance(dataFrame, pd.core.frame.DataFrame):
            raise TypeError("not of type pandas.core.frame.DataFrame")

        self.layoutAboutToBeChanged.emit()
        if copyDataFrame:
            self._dataFrame = dataFrame.copy()
        else:
            self._dataFrame = dataFrame

        self._columnDtypeModel = ColumnDtypeModel(dataFrame)
        self._columnDtypeModel.dtypeChanged.connect(self.propagateDtypeChanges)
        self._columnDtypeModel.changeFailed.connect(
            lambda columnName, index, dtype: self.changingDtypeFailed.emit(columnName, index, dtype)
        )
        self.layoutChanged.emit()
        self.dataChanged.emit()
        self.dataFrameChanged.emit()

    @pyqtSlot(int, object)
    def propagateDtypeChanges(self, column, dtype):
        self.dtypeChanged.emit(column, dtype)

    @property
    def timestampFormat(self):
        """getter to _timestampFormat"""
        return self._timestampFormat

    @timestampFormat.setter
    def timestampFormat(self, timestampFormat):
        """setter to _timestampFormat. Formatting string for conversion of timestamps to QtCore.QDateTime
        Raises:
            AssertionError: if timestampFormat is not of type unicode.
        Args:
            timestampFormat (unicode): assign timestampFormat to _timestampFormat.
                Formatting string for conversion of timestamps to QtCore.QDateTime. Used in data method.
        """
        if not isinstance(timestampFormat, (unicode, )):
            raise TypeError('not of type unicode')
        #assert isinstance(timestampFormat, unicode) or timestampFormat.__class__.__name__ == "DateFormat", "not of type unicode"
        self._timestampFormat = timestampFormat

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        """return the header depending on section, orientation and Qt::ItemDataRole
        Args:
            section (int): For horizontal headers, the section number corresponds to the column number.
                Similarly, for vertical headers, the section number corresponds to the row number.
            orientation (Qt::Orientations):
            role (Qt::ItemDataRole):
        Returns:
            None if not Qt.DisplayRole
            _dataFrame.columns.tolist()[section] if orientation == Qt.Horizontal
            section if orientation == Qt.Vertical
            None if horizontal orientation and section raises IndexError
        """
        if role != Qt.DisplayRole:
            return None

        if orientation == Qt.Horizontal:
            try:
                label = self._dataFrame.columns.tolist()[section]
                if label == section:
                    label = section
                return label
            except (IndexError, ):
                return None
        elif orientation == Qt.Vertical:
            return section

    def data(self, index, role=Qt.DisplayRole):
        """return data depending on index, Qt::ItemDataRole and data type of the column.
        Args:
            index (QtCore.QModelIndex): Index to define column and row you want to return
            role (Qt::ItemDataRole): Define which data you want to return.
        Returns:
            None if index is invalid
            None if role is none of: DisplayRole, EditRole, CheckStateRole, DATAFRAME_ROLE
            if role DisplayRole:
                unmodified _dataFrame value if column dtype is object (string or unicode).
                _dataFrame value as int or long if column dtype is in _intDtypes.
                _dataFrame value as float if column dtype is in _floatDtypes. Rounds to defined precision (look at: _float16_precision, _float32_precision).
                None if column dtype is in _boolDtypes.
                QDateTime if column dtype is numpy.timestamp64[ns]. Uses timestampFormat as conversion template.
            if role EditRole:
                unmodified _dataFrame value if column dtype is object (string or unicode).
                _dataFrame value as int or long if column dtype is in _intDtypes.
                _dataFrame value as float if column dtype is in _floatDtypes. Rounds to defined precision (look at: _float16_precision, _float32_precision).
                _dataFrame value as bool if column dtype is in _boolDtypes.
                QDateTime if column dtype is numpy.timestamp64[ns]. Uses timestampFormat as conversion template.
            if role CheckStateRole:
                Qt.Checked or Qt.Unchecked if dtype is numpy.bool_ otherwise None for all other dtypes.
            if role DATAFRAME_ROLE:
                unmodified _dataFrame value.
            raises TypeError if an unhandled dtype is found in column.
        """

        if not index.isValid():
            return None

        def convertValue(row, col, columnDtype):
            value = None
            if columnDtype == object:
                value = self._dataFrame.ix[row, col]
            elif columnDtype in self._floatDtypes:
                value = round(float(self._dataFrame.ix[row, col]), self._float_precisions[str(columnDtype)])
            elif columnDtype in self._intDtypes:
                value = int(self._dataFrame.ix[row, col])
            elif columnDtype in self._boolDtypes:
                # TODO this will most likely always be true
                # See: http://stackoverflow.com/a/715455
                # well no: I am mistaken here, the data is already in the dataframe
                # so its already converted to a bool
                value = bool(self._dataFrame.ix[row, col])

            elif columnDtype in self._dateDtypes:
                #print np.datetime64(self._dataFrame.ix[row, col])
                value = pd.Timestamp(self._dataFrame.ix[row, col])
                value = QDateTime.fromString(str(value), self.timestampFormat)
                #print value
            # else:
            #     raise TypeError, "returning unhandled data type"
            return value

        row = self._dataFrame.index[index.row()]
        col = self._dataFrame.columns[index.column()]
        columnDtype = self._dataFrame[col].dtype

        if role == Qt.DisplayRole:
            # return the value if you wanne show True/False as text
            if columnDtype == np.bool:
                result = self._dataFrame.ix[row, col]
            else:
                result = convertValue(row, col, columnDtype)
        elif role  == Qt.EditRole:
            result = convertValue(row, col, columnDtype)
        elif role  == Qt.CheckStateRole:
            if columnDtype == np.bool_:
                if convertValue(row, col, columnDtype):
                    result = Qt.Checked
                else:
                    result = Qt.Unchecked
            else:
                result = None
        elif role == DATAFRAME_ROLE:
            result = self._dataFrame.ix[row, col]
        else:
            result = None
        return result

    def flags(self, index):
        """Returns the item flags for the given index as ored value, e.x.: Qt.ItemIsUserCheckable | Qt.ItemIsEditable
        If a combobox for bool values should pop up ItemIsEditable have to set for bool columns too.
        Args:
            index (QtCore.QModelIndex): Index to define column and row
        Returns:
            if column dtype is not boolean Qt.ItemIsSelectable | Qt.ItemIsEnabled | Qt.ItemIsEditable
            if column dtype is boolean Qt.ItemIsSelectable | Qt.ItemIsEnabled | Qt.ItemIsUserCheckable
        """
        flags = super(DataFrameModel, self).flags(index)

        if not self.editable:
            return flags

        col = self._dataFrame.columns[index.column()]
        if self._dataFrame[col].dtype == np.bool:
            flags |= Qt.ItemIsUserCheckable
        else:
            # if you want to have a combobox for bool columns set this
            flags |= Qt.ItemIsEditable

        return flags

    def setData(self, index, value, role=Qt.DisplayRole):
        """Set the value to the index position depending on Qt::ItemDataRole and data type of the column
        Args:
            index (QtCore.QModelIndex): Index to define column and row.
            value (object): new value.
            role (Qt::ItemDataRole): Use this role to specify what you want to do.
        Raises:
            TypeError: If the value could not be converted to a known datatype.
        Returns:
            True if value is changed. Calls layoutChanged after update.
            False if value is not different from original value.
        """
        if not index.isValid() or not self.editable:
            return False

        if value != index.data(role):

            self.layoutAboutToBeChanged.emit()

            row = self._dataFrame.index[index.row()]
            col = self._dataFrame.columns[index.column()]
            #print 'before change: ', index.data().toUTC(), self._dataFrame.iloc[row][col]
            columnDtype = self._dataFrame[col].dtype

            if columnDtype == object:
                pass

            elif columnDtype in self._intDtypes:
                dtypeInfo = np.iinfo(columnDtype)
                if value < dtypeInfo.min:
                    value = dtypeInfo.min
                elif value > dtypeInfo.max:
                    value = dtypeInfo.max

            elif columnDtype in self._floatDtypes:
                value = np.float64(value).astype(columnDtype)

            elif columnDtype in self._boolDtypes:
                value = np.bool_(value)

            elif columnDtype in self._dateDtypes:
                # convert the given value to a compatible datetime object.
                # if the conversation could not be done, keep the original
                # value.
                if isinstance(value, QDateTime):
                    value = value.toString(self.timestampFormat)
                try:
                    value = pd.Timestamp(value)
                except Exception:
                    raise Exception(u"Can't convert '{0}' into a datetime".format(value))
                    return False
            else:
                raise TypeError("try to set unhandled data type")

            self._dataFrame.set_value(row, col, value)

            #print 'after change: ', value, self._dataFrame.iloc[row][col]
            self.layoutChanged.emit()
            return True
        else:
            return False


    def rowCount(self, index=QModelIndex()):
        """returns number of rows
        Args:
            index (QtCore.QModelIndex, optional): Index to define column and row. defaults to empty QModelIndex
        Returns:
            number of rows
        """
        # len(df.index) is faster, so use it:
        # In [12]: %timeit df.shape[0]
        # 1000000 loops, best of 3: 437 ns per loop
        # In [13]: %timeit len(df.index)
        # 10000000 loops, best of 3: 110 ns per loop
        # %timeit df.__len__()
        # 1000000 loops, best of 3: 215 ns per loop
        return len(self._dataFrame.index)

    def columnCount(self, index=QModelIndex()):
        """returns number of columns
        Args:
            index (QtCore.QModelIndex, optional): Index to define column and row. defaults to empty QModelIndex
        Returns:
            number of columns
        """
        # speed comparison:
        # In [23]: %timeit len(df.columns)
        # 10000000 loops, best of 3: 108 ns per loop

        # In [24]: %timeit df.shape[1]
        # 1000000 loops, best of 3: 440 ns per loop
        return len(self._dataFrame.columns)

    def sort(self, columnId, order=Qt.AscendingOrder):
        """sort the model column
        After sorting the data in ascending or descending order, a signal
        `layoutChanged` is emitted.
        Args:
            columnId (int): columnIndex
            order (Qt::SortOrder, optional): descending(1) or ascending(0). defaults to Qt.AscendingOrder
        """
        self.layoutAboutToBeChanged.emit()
        self.sortingAboutToStart.emit()
        column = self._dataFrame.columns[columnId]
        self._dataFrame.sort(column, ascending=not bool(order), inplace=True)
        self.layoutChanged.emit()
        self.sortingFinished.emit()

    def setFilter(self, search):
        """apply a filter and hide rows.
        The filter must be a `DataSearch` object, which evaluates a python
        expression.
        If there was an error while parsing the expression, the data will remain
        unfiltered.
        Args:
            search(pandasqt.DataSearch): data search object to use.
        Raises:
            TypeError: An error is raised, if the given parameter is not a
                `DataSearch` object.
        """
        if not isinstance(search, DataSearch):
            raise TypeError('The given parameter must an `pandasqt.DataSearch` object')

        self._search = search

        self.layoutAboutToBeChanged.emit()

        if self._dataFrameOriginal is not None:
            self._dataFrame = self._dataFrameOriginal
        self._dataFrameOriginal = self._dataFrame.copy()

        self._search.setDataFrame(self._dataFrame)
        searchIndex, valid = self._search.search()

        if valid:
            self._dataFrame = self._dataFrame[searchIndex]
            self.layoutChanged.emit()
        else:
            self.clearFilter()
            self.layoutChanged.emit()

        self.dataFrameChanged.emit()

    def clearFilter(self):
        """clear all filters.
        """
        if self._dataFrameOriginal is not None:
            self.layoutAboutToBeChanged.emit()
            self._dataFrame = self._dataFrameOriginal
            self._dataFrameOriginal = None
            self.layoutChanged.emit()

    def columnDtypeModel(self):
        """Getter for a ColumnDtypeModel.
        Returns:
            ColumnDtypeModel
        """
        return self._columnDtypeModel


    def enableEditing(self, editable):
        self.editable = editable
        self._columnDtypeModel.setEditable(self.editable)

    def dataFrameColumns(self):
        return self._dataFrame.columns.tolist()

    def addDataFrameColumn(self, columnName, dtype, defaultValue):
        if not self.editable or dtype not in SupportedDtypes.allTypes():
            return False

        elements = self.rowCount()
        columnPosition = self.columnCount()

        newColumn = pd.Series([defaultValue]*elements, index=self._dataFrame.index, dtype=dtype)

        self.beginInsertColumns(QModelIndex(), columnPosition - 1, columnPosition - 1)
        try:
            self._dataFrame.insert(columnPosition, columnName, newColumn, allow_duplicates=False)
        except ValueError(e):
            # columnName does already exist
            return False

        self.endInsertColumns()

        self.propagateDtypeChanges(columnPosition, newColumn.dtype)

        return True

    def addDataFrameRows(self, count=1):
        # don't allow any gaps in the data rows.
        # and always append at the end

        if not self.editable:
            return False

        position = self.rowCount()

        if count < 1:
            return False

        if len(self.dataFrame().columns) == 0:
            # log an error message or warning
            return False

        # Note: This function emits the rowsAboutToBeInserted() signal which
        # connected views (or proxies) must handle before the data is
        # inserted. Otherwise, the views may end up in an invalid state.
        self.beginInsertRows(QModelIndex(), position, position + count - 1)

        defaultValues = []
        for dtype in self._dataFrame.dtypes:
            if dtype.type == np.dtype('<M8[ns]'):
                val = pd.Timestamp('')
            elif dtype.type == np.dtype(object):
                val = ''
            else:
                val = dtype.type()
            defaultValues.append(val)

        for i in xrange(count):
            self._dataFrame.loc[position + i] = defaultValues
        self._dataFrame.reset_index()
        self.endInsertRows()
        return True

    def removeDataFrameColumns(self, columns):
        if not self.editable:
            return False

        if columns:
            deleted = 0
            errorOccured = False
            for (position, name) in columns:
                position = position - deleted
                if position < 0:
                    position = 0
                self.beginRemoveColumns(QModelIndex(), position, position)
                try:
                    self._dataFrame.drop(name, axis=1, inplace=True)
                except ValueError(e):
                    errorOccured = True
                    continue
                self.endRemoveColumns()
                deleted += 1
            self.dataChanged.emit()

            if errorOccured:
                return False
            else:
                return True
        return False

    def removeDataFrameRows(self, rows):
        if not self.editable:
            return False

        if rows:
            position = min(rows)
            count = len(rows)
            self.beginRemoveRows(QModelIndex(), position, position + count - 1)

            removedAny = False
            for idx, line in self._dataFrame.iterrows():
                if idx in rows:
                    removedAny = True
                    self._dataFrame.drop(idx, inplace=True)

            if not removedAny:
                return False

            self._dataFrame.reset_index(inplace=True, drop=True)

            self.endRemoveRows()
            return True
        return False

    def letterize(self, num):
        """Zamienia liczby w litery alfabetu."""
        num += 1
        num2alphadict = dict(zip(range(1, 27), string.ascii_lowercase))
        outval = ""
        numloops = (num-1) //26
        if numloops > 0:
            outval = outval + self.letterize(numloops)
        remainder = num % 26
        if remainder > 0:
            outval = outval + num2alphadict[remainder]
        else:
            outval = outval + "z"
        return outval.upper()

    def param_rank_old(self, val, val_max):
        """Zwraca wartość rankingu parametru typu float."""
        if val == 0.0:
            return 100.
        else:
            return round((((98*val)/val_max)-99)*-1,1)

    def param_rank(self, val, val_max):
        """Zwraca wartość rankingu parametru typu float."""
        if val_max == 0.0:
            return 0.0
        if val == 0.0:
            return 100.0
        else:
            a = 100
            b = np.power(1/a, 1/val_max)
            return round(a * np.power(b, val), 1)