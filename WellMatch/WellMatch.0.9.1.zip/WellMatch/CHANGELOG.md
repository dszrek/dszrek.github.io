# Changelog (dziennik zmian):

## [0.9.1] - 2021-05-10

### Zmieniono
- Fazę 3 analizy wstępnej oparto na wartościach pojedynczych parametrów, zamiast na kombinacjach uśrednionych wartości par parametrów.

### Poprawiono
- Eksport połączonych otworów do pliku .csv - do kolumny 'Y' wpisywana jest poprawna współrzędna.
